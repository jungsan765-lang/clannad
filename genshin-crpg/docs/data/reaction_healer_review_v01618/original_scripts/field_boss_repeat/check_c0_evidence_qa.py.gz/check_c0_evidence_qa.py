import collections, datetime, gzip, hashlib, json, math, pathlib
import re, statistics

B = pathlib.Path('/tmp/crpg_reaction_plan/field_boss_repeat')
ROOT = pathlib.Path('/workspace/scratch/a62414469990/crpg-v01618-work/genshin-crpg')
OUT = pathlib.Path('/tmp/crpg_reaction_plan/boss_repeat_c0_independent_qa.json')
FILES = ['e3.json', 'e6.json', 'summary.json', 'native.json.gz', 'manifest.json', 'actual_fixture.json', 'aggregate.py', 'audit.cjs', 'conditions.csv']
def meta(p):
    s=p.stat()
    return {'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
before={f:meta(B/f) for f in FILES}
errors=[]; warnings=[]; checks=collections.Counter()
def ck(value, label, context=None):
    checks[label]+=1
    if not value: errors.append({'check':label, 'context':context})
chunks=[json.loads((B/f'e{n}.json').read_text()) for n in [3,6]]
S=json.loads((B/'summary.json').read_text()); M=json.loads((B/'manifest.json').read_text()); F=json.loads((B/'actual_fixture.json').read_text())
rows=[r for c in chunks for r in c['rows']]
fixture={(r['team'],r['enhance'],r['requestedTalent']):r for r in F['rows']}
supports={'FOUR_ATTACK':['LIYUE_XIANGLING','LIYUE_XINGQIU','MOND_FISCHL'], 'FOUR_HEAL':['LIYUE_XIANGLING','LIYUE_XINGQIU','MOND_BARBARA'], 'FIVE_HYBRID':['MOND_DILUC','MOND_JEAN','LIYUE_KEQING'], 'FIVE_DEFENSIVE':['LIYUE_ZHONGLI','MOND_DILUC','MOND_JEAN'], 'FIVE_ATTACK':['MOND_DILUC','LIYUE_KEQING','LIYUE_XIAO']}
db=json.loads((ROOT/'content/db.json').read_text())
print('DB shape',type(db).__name__,list(db)[:6])
keys=[(r['team'],r['enhance'],r['talentMode'],r['seed']) for r in rows]
ck(len(keys)==len(set(keys))==60,'unique 60 condition keys')
expected={(t,e,m,s) for t in supports for e in [3,6] for m in ['MODERATE','MAX'] for s in [717,925,4242]}
ck(set(keys)==expected,'full expected design')
ck(len(F['rows'])==len(fixture)==20,'unique 20 actual fixtures')
packet_pairs=0; changed_packets=0; net_zero_with_damage=0; non_xiao_residuals=[]; xiao_rows=[]; core_completions=0; core_revivals=0
core_win_without_four=0; core_fail_without_four=0; sample_changes=[]; recovery_failures=0; comparable=0; interim_recoveries=0
condition_lookup={(r['team'],r['enhance'],r['talentMode'],r['seed']):r for r in S['conditions']}
for r in rows:
    key=(r['team'],r['enhance'],r['talentMode'],r['seed']); sr=condition_lookup[key]
    ck(r['teamIds']==supports[r['team']],'team IDs',key)
    t=4 if r['talentMode']=='MAX' else 2
    ck(r['talent']==t,'actual talent scalar',key)
    ck(all(set(v.values())=={t} for v in r['talents'].values()),'actual saved talents',key)
    ck(all(i['enhance']==r['enhance'] for i in r['equipment']),'actual equipment enhancement',key)
    ck(all('ARTIFACT' not in i.get('category','') for i in r['equipment']),'no equipped artifacts',key)
    ck(len(r['equipment'])==12,'four actors x three gear pieces',key)
    ck(all(a['hp']==a['maxHp'] and a['level']==25 for a in r['initialHp']),'initial full HP Lv25',key)
    fr=fixture[(r['team'],r['enhance'],t)]
    ck([a['owner'] for a in fr['actors']]==['PLAYER_CUSTOM',*supports[r['team']]],'actual fixture party',key)
    for a in fr['actors']:
        g=a['growth']; tl=a['talentLevels']
        ck((g['level'],g['phase'],g['cap'],g['talentCap'])==(25,2,30,4),'legal actual level phase cap',key)
        ck(all(tl[k]==t and tl['base'][k]==t for k in ['na','e','q']),'actual effective talents C0',key)
        ck(len(a['equipment'])==3 and all(i['enhance']==r['enhance'] for i in a['equipment']),'actual fixture equipment',key)
    ck(r['wins']==sum(b['win'] for b in r['battles']),'row win count',key)
    ck(r['losses']==sum(not b['win'] for b in r['battles']),'row loss count',key)
    ck(not r['losses'] or (not r['battles'][-1]['win'] and r['stopReason']=='DEFEAT'),'stop after defeat',key)
    ck(len(r['battles'])<=3,'at most three boss attempts',key)
    if r.get('recoveryFailure'): recovery_failures+=1
    eligibility=not r.get('recoveryFailure') and r['wins']==3 and r.get('endpoint',{}).get('allFullHp')
    expected_inn=r['lodgingMora'] if eligibility else None
    ck(sr['innMoraComparableAfterThreeWins']==expected_inn,'inn successful-three-win denominator',key)
    if eligibility: comparable+=1
    if r.get('recoveryFailure'):
        ck(r['lodgingMora']==0 and sr['innMoraComparableAfterThreeWins'] is None,'failed inn zero excluded',key)
    total_damage=0; allpackets=[]
    for i,b in enumerate(r['battles']):
        sb=sr['battles'][i]; allies={a['source'] for a in b['initial'] if a['side']=='ALLY'}
        ck(len(allies)==4,'native four ally actors',(*key,i))
        ck(all(a['level']==25 for a in b['initial'] if a['side']=='ALLY'),'all native allies Lv25',(*key,i))
        ck(next(a for a in b['initial'] if a['side']=='ENEMY')['level']==30,'native boss Lv30',(*key,i))
        if i:
            ck(b['before']==r['battles'][i-1]['after'],'persistent HP before next boss no inn',(*key,i))
        native_logs=[l for l in b['lastLog'] if 'damage' in l and l.get('targetId') in allies and (l.get('actorId','').startswith('FB_CRYO_HYPOSTASIS') or l.get('actorId','').startswith('HAZARD'))]
        ck(len(native_logs)==len(b['incomingPackets']),'ordered packet/log count',(*key,i))
        old_damage=b['allyHpDamage']; corrected=0
        for j,(p,l) in enumerate(zip(b['incomingPackets'],native_logs)):
            ck((p['target'],p['details'].get('card'),p['round'])==(l['targetId'],l.get('card'),l['round']),'ordered target card round matches',(*key,i,j))
            ck(p['actor']==('HAZARD' if l.get('actorId','').startswith('HAZARD') else 'FB_CRYO_HYPOSTASIS'),'ordered actor matches',(*key,i,j))
            pre=next((a['hp'] for a in l.get('presentationActorsBefore',[]) if a['id']==p['target'] and 'hp' in a),p['beforeHp'])
            damage=min(l['damage'],pre)
            ck(damage>=0 and damage<=pre,'bounded actual HP damage',(*key,i,j))
            ck(pre-damage==p['afterHp'],'native damage with actual pre-hit HP gives after',(*key,i,j))
            if damage!=p['hpLoss']:
                changed_packets+=1
                if len(sample_changes)<8:sample_changes.append({'condition':key,'fight':i+1,'packet':j,'outerBefore':p['beforeHp'],'actualBefore':pre,'outerAfter':p['afterHp'],'outerNetLoss':p['hpLoss'],'actualDamage':damage})
            if p['hpLoss']==0 and damage>0:net_zero_with_damage+=1
            p['observedOuterNetHpLoss']=p['hpLoss'];p['nativeDamageBeforeOverkillCap']=l['damage'];p['actualPreHitHp']=pre;p['hpLoss']=damage
            corrected+=damage;packet_pairs+=1
        b['observedOuterNetHpLoss']=old_damage;b['allyHpDamage']=corrected;total_damage+=corrected;allpackets+=b['incomingPackets']
        ck(sb['hpDamage']==corrected,'corrected battle damage summary',(*key,i))
        ck(old_damage==sum(p['observedOuterNetHpLoss'] for p in b['incomingPackets']),'observed outer packet sum',(*key,i))
        ck(b['effectiveHealing']==sum(h['effective'] for h in b['heals']),'actual healing sum',(*key,i))
        for a in b['initial']:
            if a['side']!='ALLY':continue
            end=next(v for v in b['beforeReward'] if v['source']==a['source'])
            ps=[p for p in b['incomingPackets'] if p['target']==a['source']]
            heal=sum(h['effective'] for h in b['heals'] if h['target']==a['source'])
            residual=a['hp']-sum(p['hpLoss'] for p in ps)+heal-end['hp']
            reported=next(x for x in sb['directHpBalance'] if x['actor']==a['source'])
            ck(reported['directHpLossOutsideDamagePipeline']==residual,'HP balance summary',(*key,i,a['source']))
            if a['source']!='LIYUE_XIAO':
                non_xiao_residuals.append(residual);ck(residual==0,'non Xiao HP balance reconciles zero',(*key,i,a['source']))
            else:
                ck(heal==0,'Xiao isolated direct-cost fixture has no healing',(*key,i))
                qrounds=[c['round'] for c in b['actualCasts'] if c['card']=='LIYUE_XIAO_Q']
                hp=a['hp'];prev_round=1;self_loss=0;tick_count=0
                def expected_gap(until_round):
                    nonlocal_dummy=None
                    return [rn for rn in range(prev_round,until_round) if any(q<=rn<=q+2 for q in qrounds)]
                for p in ps:
                    for rn in expected_gap(p['round']):
                        if hp>0:
                            loss=min(max(0,hp-1),math.floor(a['maxHp']*.08));hp-=loss;self_loss+=loss;tick_count+=1
                    ck(hp==p['actualPreHitHp'],'Xiao exact 8pct END gap before next packet',(*key,i,p['round'],hp,p['actualPreHitHp']))
                    hp-=p['hpLoss'];prev_round=p['round']
                for rn in expected_gap(b['rounds']):
                    if hp>0:
                        loss=min(max(0,hp-1),math.floor(a['maxHp']*.08));hp-=loss;self_loss+=loss;tick_count+=1
                ck(hp==end['hp'] and self_loss==residual,'Xiao exact 8pct plus minimum1 final balance',(*key,i,hp,end['hp'],self_loss,residual))
                xiao_rows.append({'condition':key,'fight':i+1,'qRounds':qrounds,'tickCount':tick_count,'fixed8pct':math.floor(a['maxHp']*.08),'actualDirectLoss':residual,'reconstructedDirectLoss':self_loss})
        completions=sum(l.get('card')=='FB_CORE_BROKEN' for l in b['lastLog']); revivals=sum(l.get('card')=='FB_REVIVED' for l in b['lastLog']);core_completions+=completions;core_revivals+=revivals
        ck(sb['core']['completedFourHits']==completions and sb['core']['timedOutAndRevived50Percent']==revivals,'core counts',(*key,i))
        boss_initial=next(a for a in b['initial'] if a['side']=='ENEMY')
        for l in b['lastLog']:
            if l.get('card')=='FB_REVIVED':
                post=next(a['hp'] for a in l['presentationActorsAfter'] if a['id'].startswith('FB_CRYO_HYPOSTASIS') and 'hp' in a)
                ck(post==math.floor(boss_initial['maxHp']*.5),'actual native revival HP exactly50pct',(*key,i))
        if completions:ck(b['win'],'completed four hit cores are victories',(*key,i))
        for c in b['coreHits']:
            ck(c['before']['need']==4 and (c['after'] is None or c['after']['need']==4),'native core needs four',(*key,i))
            if c['after'] is None:
                ck(c['before']['hits']==3 and completions>0,'fourth hit clears completed core state',(*key,i))
            else:
                ck(c['after']['hits']==c['before']['hits']+1,'core hit increments one',(*key,i))
        if b['win'] and not completions:
            core_win_without_four+=1;ck(revivals>=1,'victory without four core hits requires timeout revival',(*key,i))
            ck(b['bossBeforeReward']['hp']==0,'second kill boss HP zero',(*key,i))
        elif not b['win'] and not completions:core_fail_without_four+=1
    r['mainObservedNetHpLoss']=r['mainHpDamage'];r['mainHpDamage']=total_damage
    ck(sr['mainHpDamage']==total_damage and sr['mainObservedNetHpLoss']==r['mainObservedNetHpLoss'],'corrected condition damage',key)
with gzip.open(B/'native.json.gz','rt',encoding='utf8') as f:native=json.load(f)
ck(native.get('chunks')==chunks,'compressed native exactly equals independently corrected raw chunks')
del native
counts={'campaigns':len(rows),'uniqueConditionKeys':len(set(keys)),'nativeMainFights':sum(len(r['battles']) for r in rows),'mainWins':sum(r['wins'] for r in rows),'mainLosses':sum(r['losses'] for r in rows),'firstFightWins':sum(r['battles'][0]['win'] for r in rows),'allThreeWinCampaigns':sum(r['wins']==3 for r in rows),'nativeRecoveryFailures':recovery_failures,'matchedNativeDamagePackets':packet_pairs,'nonXiaoUnreconciledHpBalance':sum(x!=0 for x in non_xiao_residuals),'fourCoreHitCompletions':core_completions,'coreTimeout50PercentRevivals':core_revivals,'executionErrors':[e for c in chunks for e in c['errors']]}
ck(counts==S['count'],'all independently recomputed summary counts')
ck(counts==M['finalCounts'],'all independently recomputed manifest counts')
def minmax(values):
    v=list(values)
    return {'min':min(v),'max':max(v),'mean':statistics.mean(v)} if v else None
for g in S['groups']:
    rr=[r for r in rows if (r['team'],r['enhance'],r['talentMode'])==(g['team'],g['enhance'],g['talentMode'])]
    ff=[r['battles'][0] for r in rr];gg=[r for r in rr if r['wins']==3]
    independent={'team':g['team'],'enhance':g['enhance'],'talentMode':g['talentMode'],'campaigns':len(rr),'allThreeWins':len(gg),'firstBattleWins':sum(b['win'] for b in ff),'wins':sum(r['wins'] for r in rr),'losses':sum(r['losses'] for r in rr),'firstRounds':minmax(b['rounds'] for b in ff),'firstSecondsModel2x':minmax(b['seconds'] for b in ff),'firstHpDamage':minmax(b['allyHpDamage'] for b in ff),'firstShieldAbsorbed':minmax(b['shieldAbsorbed'] for b in ff),'firstActualHeal':minmax(b['effectiveHealing'] for b in ff),'threeWinsEndHpRatio':minmax(r['afterMainHpRatio'] for r in gg),'threeWinsHpDamage':minmax(r['mainHpDamage'] for r in gg),'threeWinsShieldAbsorbed':minmax(r['mainShieldAbsorbed'] for r in gg),'threeWinsActualHeal':minmax(r['mainEffectiveHealing'] for r in gg),'threeWinsDirectSelfHpLoss':minmax(condition_lookup[(r['team'],r['enhance'],r['talentMode'],r['seed'])]['directHpLossOutsideDamagePipeline'] for r in gg),'threeWinsSecondsModel2x':minmax(r['mainSeconds'] for r in gg),'threeWinsInnMora':minmax(r['lodgingMora'] for r in gg if not r.get('recoveryFailure') and r.get('endpoint',{}).get('allFullHp')),'firstCoreFourHitCompletions':sum(l.get('card')=='FB_CORE_BROKEN' for b in ff for l in b['lastLog']),'firstCoreTimeoutsRevived':sum(l.get('card')=='FB_REVIVED' for b in ff for l in b['lastLog']),'firstDamageKo':sum(b['ko'] for b in ff)}
    ck(g==independent,'independent entire group aggregation',(g['team'],g['enhance'],g['talentMode']))
wish=(ROOT/'source/runtime_wish_v01411.js').read_text()
pool=lambda name:set(re.findall(r"'(.*?)'",re.search(r'const '+name+r'=\[(.*?)\];',wish).group(1)))
four=pool('FOUR');five=pool('STANDARD5')|pool('LIMITED5')
for team,ids in supports.items():ck(set(ids)<=(four if team.startswith('FOUR_') else five),'actual runtime companion rarity',team)
for f,m in M['artifacts'].items():ck(before[f]['bytes']==m['bytes'] and before[f]['sha256']==m['sha256'],'manifest artifact hash',f)
for f,h in M['scriptSHA256'].items():ck(before[f]['sha256']==h,'manifest script hash',f)
baseline=json.loads(pathlib.Path('/tmp/crpg_healer_audit/source_before.json').read_text())
product={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in baseline}
ck(len(product)==233,'233 product source plus DB files')
ck(product==baseline,'product source plus DB baseline unchanged')
ck(product==M['gameFilesSHA256'],'manifest current product file hashes')
ck(S['sourceFilesCount']==233 and S['sourceFilesUnchanged'] and M['gameFilesUnchanged'],'unchanged boolean flags')
ck(all(c['sourceCommit']=='1e1b2442b53d42873d29556898f5f612d52d0c7a' and c['fingerprint']==S['nativeFingerprint']==F['fingerprint'] for c in chunks),'published source and native fingerprint')
script=(B/'audit.cjs').read_text(); helper=(ROOT/'tools/audit_protagonist_v01618.cjs').read_text()
ck('H.load(root)' in script and 'H.load(root,' not in script,'native VM no candidate substitution')
ck('H.recover' in script and script.index('out.afterMainHp=')<script.index('H.recover'),'recovery only after main boss campaign')
ck('s.constellations' not in script and 's.constellations' not in helper,'no fixture constellation grant')
warnings.extend([
    'C0 condition data have no saved constellation object. C0 is supported by fresh newGame/no constellation-grant code and actual base=effective talent equality; not a user save claim.',
    'All main repeats have no intermediate lodging. Recovery denominator is 36 successful three-win campaigns; 24 defeat recovery failures have lodgingMora=0 but comparable inn cost=null.',
    'FIVE_* and FOUR_* designate companion rarity, not party size: all native parties contain Traveler plus three companions. Fixed 5-star artifact/weapon premium is not tested.',
    '2x seconds are presentation model plus input budget, not measured browser wall time. Native recovery may include road battles and healing; finale inn cost differs from a boss-location quote.',
    'Core wins without four hits are native timeout + 50pct HP revival + second kills, not a successful four-hit core mechanic. Do not aggregate them as core destruction.',
    'Inputs and source hashes are checked read-only. No runtime experiment or product, DB, Git, or documentation mutation performed.'
])
after={f:meta(B/f) for f in FILES};ck(before==after,'all audit inputs hashes sizes mtimes unchanged')
out={'generatedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qaScope':'C0 only read-only independent recomputation','sourceCommit':S['sourceCommit'],'inputFiles':before,'inputsUnchanged':before==after,'checks':dict(checks),'recomputedCounts':counts,'extra':{'correctedDamageChangedPackets':changed_packets,'outerZeroNetButActualDamagePackets':net_zero_with_damage,'sampleHealBeforeHitCorrections':sample_changes,'nonXiaoActorBalances':len(non_xiao_residuals),'XiaoBalances':len(xiao_rows),'XiaoDirectLossSum':sum(x['actualDirectLoss'] for x in xiao_rows),'XiaoExpected8pctDirectLossSum':sum(x['reconstructedDirectLoss'] for x in xiao_rows),'XiaoEvidence':xiao_rows,'comparableThreeWinInnCampaigns':comparable,'winsWithoutFourHitCoreCompletions':core_win_without_four,'lossesWithoutFourHitCoreCompletions':core_fail_without_four,'mainRecoveryPolicy':'No intermediate recovery; final native inn attempt only'},'errors':errors,'warnings':warnings,'passed':not errors}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(OUT),'counts':counts,'checks':sum(checks.values()),'errorCount':len(errors),'errorsSample':errors[:12],'extra':{k:v for k,v in out['extra'].items() if k not in ['XiaoEvidence','sampleHealBeforeHitCorrections']}},ensure_ascii=False,indent=2))
