import collections, datetime, gzip, hashlib, json, math, pathlib
B=pathlib.Path('/tmp/crpg_reaction_plan/field_boss_repeat');ROOT=pathlib.Path('/workspace/scratch/a62414469990/crpg-v01618-work/genshin-crpg')
OUT=pathlib.Path('/tmp/crpg_reaction_plan/boss_repeat_c6_independent_qa.json')
files=['c6_e3.json','c6_e6.json','c6_summary.json','c6_native.json.gz','c6_manifest.json','aggregate_c6.py','audit_c6.cjs','c6_conditions.csv','actual_fixture.json']
def meta(p):
 s=p.stat();return {'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
inputs={f:meta(B/f) for f in files};errors=[];checks=collections.Counter()
def ck(ok,label,context=None):
 checks[label]+=1
 if not ok:errors.append({'check':label,'context':context})
chunks=[json.loads((B/f'c6_e{e}.json').read_text()) for e in [3,6]];rows=[r for c in chunks for r in c['rows']]
S=json.loads((B/'c6_summary.json').read_text());M=json.loads((B/'c6_manifest.json').read_text())
key=lambda r:(r['team'],r['enhance'],r['talentMode'],r['seed'])
keys=[key(r) for r in rows];ck(len(keys)==len(set(keys))==12,'12 unique conditions')
ck(set(keys)=={(t,e,'MAX',s) for t in ['FOUR_ATTACK','FOUR_HEAL'] for e in [3,6] for s in [717,925,4242]},'expected independent C6 design')
look={key(r):r for r in S['conditions']};pairs=0;changed=0;hp_residuals=[];allfights=[]
for r in rows:
 k=key(r);sr=look[k];owners=['PLAYER_CUSTOM',*r['teamIds']]
 ck(r['constellations']=={o:(0 if o=='PLAYER_CUSTOM' else 6) for o in owners},'actual saved companion6 Traveler0',k)
 ck(sr['constellations']==r['constellations'] and sr['actualTalents']==r['actualTalents'],'summary saved constellation and talents',k)
 for a in r['actualTalents']:
  lvl=a['levels'];owner=a['owner'];expected=(4,4,4) if owner=='PLAYER_CUSTOM' else (4,7,7)
  ck(tuple(lvl[x] for x in ['na','e','q'])==expected,'effective na4 e7 q7 except Traveler4',(*k,owner))
  ck(tuple(lvl['base'][x] for x in ['na','e','q'])==(4,4,4),'base talents4',(*k,owner))
  g=a['growth'];ck((g['level'],g['phase'],g['cap'],g['talentCap'])==(25,2,30,4),'Lv25 phase2 legal cap4',(*k,owner))
 ck(all(x['enhance']==r['enhance'] for x in r['equipment']) and len(r['equipment'])==12,'actual same enhancement twelve gear',k)
 ck(len(r['initialHp'])==4 and all(a['hp']==a['maxHp'] and a['level']==25 for a in r['initialHp']),'first full HP once Lv25',k)
 ck(r['wins']==sum(b['win'] for b in r['battles']) and r['losses']==sum(not b['win'] for b in r['battles']),'native win loss counts',k)
 if r['team']=='FOUR_HEAL':ck(r['wins']==3 and r['losses']==0 and len(r['battles'])==3,'healing all six campaigns three wins',k)
 else:ck(r['wins']==1 and r['losses']==1 and [b['win'] for b in r['battles']]==[True,False],'attack all six win first lose second',k)
 eligible=not r.get('recoveryFailure') and r['wins']==3 and r.get('endpoint',{}).get('allFullHp')
 ck(sr['innMoraComparableAfterThreeWins']==(r['lodgingMora'] if eligible else None),'comparable inn only successful three wins',k)
 if r.get('recoveryFailure'):ck(r['lodgingMora']==0 and sr['innMoraComparableAfterThreeWins'] is None,'defeat zero cost null',k)
 original_damage=r['mainHpDamage'];total=0
 for i,b in enumerate(r['battles']):
  allfights.append(b);sb=sr['battles'][i];allies={a['source'] for a in b['initial'] if a['side']=='ALLY'}
  ck(len(allies)==4,'native party four',(*k,i))
  if i:ck(b['before']==r['battles'][i-1]['after'],'persistent HP no intermediate inn',(*k,i))
  logs=[l for l in b['lastLog'] if 'damage' in l and l.get('targetId') in allies and (l.get('actorId','').startswith('FB_CRYO_HYPOSTASIS') or l.get('actorId','').startswith('HAZARD'))]
  ck(len(logs)==len(b['incomingPackets']),'packet native ordered count',(*k,i));old=b['allyHpDamage'];corrected=0
  for j,(p,l) in enumerate(zip(b['incomingPackets'],logs)):
   ck((p['target'],p['details'].get('card'),p['round'])==(l['targetId'],l.get('card'),l['round']),'ordered native target card round',(*k,i,j))
   pre=next((a['hp'] for a in l.get('presentationActorsBefore',[]) if a['id']==p['target'] and 'hp' in a),p['beforeHp']);damage=min(l['damage'],pre)
   ck(pre-damage==p['afterHp'],'native actual before less bounded damage after',(*k,i,j));changed+=damage!=p['hpLoss'];pairs+=1
   p['observedOuterNetHpLoss']=p['hpLoss'];p['nativeDamageBeforeOverkillCap']=l['damage'];p['actualPreHitHp']=pre;p['hpLoss']=damage;corrected+=damage
  b['observedOuterNetHpLoss']=old;b['allyHpDamage']=corrected;total+=corrected;ck(corrected==sb['hpDamage'],'summary corrected native damage',(*k,i))
  boss_initial=next(a for a in b['initial'] if a['side']=='ENEMY')
  for l in b['lastLog']:
   if l.get('card')=='FB_REVIVED':
    post=next(a['hp'] for a in l['presentationActorsAfter'] if a['id'].startswith('FB_CRYO_HYPOSTASIS') and 'hp' in a)
    ck(post==math.floor(boss_initial['maxHp']*.5),'actual native revival exactly50pct',(*k,i))
  for a in b['initial']:
   if a['side']!='ALLY':continue
   end=next(x for x in b['beforeReward'] if x['source']==a['source']);damage=sum(p['hpLoss'] for p in b['incomingPackets'] if p['target']==a['source']);heal=sum(h['effective'] for h in b['heals'] if h['target']==a['source']);residual=a['hp']-damage+heal-end['hp'];hp_residuals.append(residual);ck(residual==0,'all actors actual HP balance zero',(*k,i,a['source']))
 r['mainObservedNetHpLoss']=original_damage;r['mainHpDamage']=total;ck(sr['mainHpDamage']==total,'condition corrected native damage',k)
with gzip.open(B/'c6_native.json.gz','rt',encoding='utf8') as f:native=json.load(f)
ck(native['chunks']==chunks,'compressed native exactly corrected source chunks')
counts={'campaigns':len(rows),'uniqueConditionKeys':len(set(keys)),'nativeMainFights':len(allfights),'mainWins':sum(r['wins'] for r in rows),'mainLosses':sum(r['losses'] for r in rows),'firstFightWins':sum(r['battles'][0]['win'] for r in rows),'allThreeWinCampaigns':sum(r['wins']==3 for r in rows),'nativeRecoveryFailures':sum(bool(r.get('recoveryFailure')) for r in rows),'matchedNativeDamagePackets':pairs,'nonXiaoUnreconciledHpBalance':sum(x!=0 for x in hp_residuals),'fourCoreHitCompletions':sum(l.get('card')=='FB_CORE_BROKEN' for b in allfights for l in b['lastLog']),'coreTimeout50PercentRevivals':sum(l.get('card')=='FB_REVIVED' for b in allfights for l in b['lastLog']),'executionErrors':[e for c in chunks for e in c['errors']]}
ck(counts==S['count']==M['finalCounts'],'independent C6 summary manifest counts')
for f,m in M['artifacts'].items():ck(inputs[f]['sha256']==m['sha256'] and inputs[f]['bytes']==m['bytes'],'manifest artifact hash',f)
for f,h in M['scriptSHA256'].items():ck(inputs[f]['sha256']==h,'manifest script hash',f)
baseline=json.loads(pathlib.Path('/tmp/crpg_healer_audit/source_before.json').read_text());product={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in baseline}
ck(product==baseline==M['gameFilesSHA256'] and len(product)==233,'all 233 product DB unchanged')
script=(B/'audit_c6.cjs').read_text();ck('H.load(root)' in script and 'H.load(root,' not in script,'no candidate runtime substitution');ck('s.constellations??={})[owner]=6' in script and 's.constellations??={}).PLAYER_CUSTOM=0' in script,'native saved fixture grants correctly written')
after={f:meta(B/f) for f in files};ck(inputs==after,'all read-only inputs hash size mtime unchanged')
out={'generatedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qaScope':'C6 separate exploratory supplement only','sourceCommit':S['sourceCommit'],'inputFiles':inputs,'inputsUnchanged':inputs==after,'checks':dict(checks),'recomputedCounts':counts,'extra':{'correctedDamageChangedPackets':changed,'allActorHpBalances':len(hp_residuals),'healingThreeWinCampaigns':sum(r['team']=='FOUR_HEAL' and r['wins']==3 for r in rows),'attackFirstWinSecondLossCampaigns':sum(r['team']=='FOUR_ATTACK' and [b['win'] for b in r['battles']]==[True,False] for r in rows)},'errors':errors,'warnings':['C6 is diagnostic ownership/constellation grant, not measured acquisition cost; Traveler is C0.','C6 evidence must remain separate from C0 60-condition denominator.','Only two four-star companion teams, six conditions each. No five-star C6 test or all-team balance claim.','No intermediate lodging; final failed recovery zeros excluded from successful three-win cost denominator.','No new runtime experiment or product, DB, Git, or documentation changes.'],'passed':not errors}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'output':str(OUT),'counts':counts,'errorCount':len(errors),'errors':errors[:10],'checks':sum(checks.values()),'extra':out['extra']},ensure_ascii=False,indent=2))
