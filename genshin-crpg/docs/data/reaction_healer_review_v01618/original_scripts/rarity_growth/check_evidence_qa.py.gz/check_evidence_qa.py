import hashlib,json,math,re,collections,datetime
from pathlib import Path

ROOT=Path('/workspace/scratch/a62414469990/crpg-v01618-work/genshin-crpg')
DIR=Path('/tmp/crpg_reaction_plan/rarity_growth')
OUT=Path('/tmp/crpg_reaction_plan/rarity_growth_evidence_qa.json')
INPUTS=[DIR/n for n in ['REVIEW_KO.md','observation.json','observe.cjs','supplement.cjs','sourcehash.json']]
BASE=Path('/tmp/crpg_healer_audit/source_before.json')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def meta(p):
 s=p.stat();return {'path':str(p),'sha256':digest(p),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns}
before={str(p):meta(p) for p in INPUTS+[BASE]}
o=json.loads((DIR/'observation.json').read_text());sh=json.loads((DIR/'sourcehash.json').read_text());baseline=json.loads(BASE.read_text())
db=json.loads((ROOT/'content/db.json').read_text());char={r[0]:r for r in db['07_CHAR_DB'][1:]}
errors=[];warnings=[];checks={}
def ck(name,condition,details=None):
 checks[name]={'passed':bool(condition),'details':details}
 if not condition:errors.append(name)
def same(a,b):return math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-8)
def jround(n):return math.floor(n+.5)

current={f:digest(ROOT/f) for f in baseline}
ck('233_product_source_and_db_hashes',len(baseline)==233 and current==baseline,{'count':len(baseline),'changed':[f for f in baseline if current[f]!=baseline[f]]})
current12={f:digest(ROOT/f) for f in sh['sourceHashes']}
ck('12_sourcehash_files_current',current12==sh['sourceHashes']==sh['afterHashes']==o['sourceHashes'] and sh['unchanged'] and o['unchanged'],{'count':len(current12)})
index=(ROOT/'source/index.html').read_text();hasher=hashlib.sha256();scripts=re.findall(r'<script src="((?:world_content|liyue_card_content|runtime[^" ]*)\.js)"',index)
for f in scripts:hasher.update(f.encode());hasher.update((ROOT/'source'/f).read_bytes())
hasher.update((ROOT/'content/db.json').read_bytes());fp=hasher.hexdigest()
ck('runtime_fingerprint_static_recalculation',fp==o['fingerprint']==sh['fingerprint']==o['fingerprintAfterSupplement'] and o['supplementSameSourceFingerprint'],{'fingerprint':fp,'scriptCount':len(scripts)})

src=(ROOT/'source/runtime_constellations_v01411.js').read_text();start=src.index('const NAMES={')+len('const NAMES=');end=src.index('\n};',start)+2
names=json.loads(re.sub(r',\s*}', '}', re.sub(r'(?m)^(\s*)([A-Z0-9_]+):',r'\1"\2":',re.sub(r'(?m)^\s*//.*$', '',src[start:end]))))
roster=o['roster'];ids=[r['id'] for r in roster];supported=o['coverage']['currentSupportedCompanionOwners'];fixtures=o['fixtureTests'];stats=o['stats']
rarities=collections.Counter(r['rarity'] for r in roster)
ready=set(r[2] for r in db['08_SKILL_CARD_DB'][1:] if len(r)>35 and r[35]=='READY' and r[2] in char)
ck('43_supported_unique_companions',len(ids)==len(set(ids))==43 and set(ids)==set(supported)==(set(names)&set(char)),{'rarities':dict(rarities),'currentSupportRecorded':o['coverage']['currentSupportedCompanionCount']})
ck('4_star_24_and_5_star_19',rarities=={4:24,5:19})
effect_block=src[src.index('const EFFECTS={'):src.index('// ---- reads ----')]
effect_keys=set(re.findall(r'(?m)^ ([A-Z0-9_]+):\{',effect_block))
ck('46_names_and_effect_sets',len(names)==46 and set(names)==effect_keys and o['coverage']['nameCount']==46 and o['coverage']['effectCount']==46,{'staticEffectKeys':len(effect_keys)})
ck('119_ready_owners_and_76_unavailable',len(ready)==119 and len(ready-set(ids))==76 and set(o['coverage']['readyOwnersMissingNames'])==ready-set(ids),{'readyOwners':len(ready),'notNamedCurrentSupport':len(ready-set(ids))})
ck('no_recorded_definition_gaps',all(not o['coverage'][k] for k in ['namedMissingNodeData','currentSupportedMissingNames','currentSupportedMissingEffects','effectTypesMissingLiteralHandler']))
effect_types=collections.Counter();roster_gaps=[]
for row in roster:
 id=row['id'];n=names[id]
 if row['rarity']!=n[1] or len(row['nodes'])!=6 or [p['name'] for p in row['nodes']]!=n[6]:roster_gaps.append(id)
 for step in ['1','2','4','6']:
  fx=row['effects'].get(step,{})
  if not fx.get('text') or not fx.get('fx'):roster_gaps.append(id+':'+step)
  for f in fx.get('fx',[]):effect_types[f['t']]+=1
ck('roster_names_and_c1_c2_c4_c6_definition',not roster_gaps,{'gaps':roster_gaps,'topLevelEffectTypesAcross43':len(effect_types)})
handlers=set(re.findall(r"fx\.t==='([^']+)'",src))
ck('22_recorded_top_level_effect_types_have_literal_handler',len(o['coverage']['effectTypes'])==22 and set(o['coverage']['effectTypes'])<=handlers,{'typeCount':len(o['coverage']['effectTypes']),'missing':sorted(set(o['coverage']['effectTypes'])-handlers)})

installed_bad=[]
for row in roster:
 for key,col in [('hp',7),('atk',8),('def',9)]:
  expected=jround(float(char[row['id']][col])*1.1) if row['rarity']==5 else float(char[row['id']][col])
  if not same(row['rawBase'][key],char[row['id']][col]) or not same(row['installedBase'][key],expected):installed_bad.append({'id':row['id'],'stat':key,'expected':expected,'recorded':row['installedBase'][key]})
ck('authored_to_installed_five_star_10_percent',not installed_bad,installed_bad)
byid={r['id']:r for r in roster};levels=[1,10,20,25,30,40,50,60];caps=[10,20,30,40,50,55,60];talentcaps=[1,2,4,6,8,9,10]
expected_keys={(id,L) for id in ids for L in levels};actual_keys=[(s['id'],s['level']) for s in stats]
ck('344_unique_stats_43_by_8',len(stats)==344 and len(set(actual_keys))==344 and set(actual_keys)==expected_keys,{'records':len(stats),'unique':len(set(actual_keys)),'levels':levels})
statbad=[]
for s in stats:
 L=s['level'];p=next(i for i,c in enumerate(caps) if c>=L);hc=1+.13*(L-1)+.002*(L-1)**2;ac=1+.12*(L-1)+.003*(L-1)**2;five=s['rarity']==5;b=byid[s['id']]['installedBase'];factor=1+(.28 if five else .20)*p
 expected={'phase':p,'maxHp':jround(jround(b['hp']*hc)*(1+(.24 if five else .16)*p)),'atk':jround(b['atk']*ac)*factor,'def':jround(b['def']*ac)*factor,'effectiveDef':jround(b['def']*ac)*factor/math.sqrt(ac),'baseAttack':jround(b['atk']*ac*factor),'reactionBase':(25+12*L)*max(1,hc/3)}
 for key,val in expected.items():
  if not same(s[key],val):statbad.append({'id':s['id'],'level':L,'stat':key,'expected':val,'recorded':s[key]})
ck('344_stats_independent_curve_phase_and_defense_math',not statbad,{'mismatchCount':len(statbad),'firstMismatches':statbad[:12]})
curve=o['talentCurve']['CURVE'];fixturebad=[];unlockcount=0
for f in fixtures:
 id=f['id'];b=f['before'];a=f['after'];unlockcount+=len(f['publicUnlocks']);expectedkind={'c3':names[id][5][0],'c5':names[id][5][1]}
 ok=(f['rarity']==names[id][1] and all(b['talents'][k]==4 and a['talents'][k]==(4 if k=='na' else 7) and a['talents']['base'][k]==4 for k in ['na','e','q']) and a['talents']['kinds']==b['talents']['kinds']==expectedkind and [(p['ok'],p['level']) for p in f['publicUnlocks']]==[(True,n) for n in range(1,7)] and f['itemRemaining']==0)
 ok=ok and all(b['actor'][k]==a['actor'][k] for k in ['maxHp','atk','def']) and f['hpUnchanged'] and f['atkUnchanged'] and f['defUnchanged']
 if not ok:fixturebad.append(id)
ck('43_unique_c6_public_unlock_fixtures',len(fixtures)==len({f['id'] for f in fixtures})==43 and {f['id'] for f in fixtures}==set(ids) and not fixturebad,{'fixtures':len(fixtures),'unlockReceipts':unlockcount,'bad':fixturebad,'baseTalent':4,'effectiveTalents':{'na':4,'e':7,'q':7},'nativeMinimumPhase':2,'legalTalentCap':talentcaps[2]})
ck('talent_curve_4_to7_and10_to13_metadata',curve==[100,108,117,127,138,150,163,177,192,208,225,243,262] and same(curve[6]/curve[3],1.283464566929134) and same(curve[12]/curve[9],1.2596153846153846),{'4to7':curve[6]/curve[3],'10to13':curve[12]/curve[9]})
phasebad=[]
for row in o['formulaByPhase']:
 p=row['phase']
 if not same(row['hpRatioForIdenticalAuthoredBaseNoEquipment'],1.1*(1+.24*p)/(1+.16*p)) or not same(row['atkDefRatioForIdenticalAuthoredBaseNoEquipment'],1.1*(1+.28*p)/(1+.20*p)):phasebad.append(p)
ck('7_same_authored_base_no_equipment_phase_ratios',len(o['formulaByPhase'])==7 and not phasebad,{'bad':phasebad,'roundingLimit':'Ratios are idealized continuous-base ratios; rounded authored/installed bases and character-specific DB stats differ.'})

jean=o['jeanC2Probe'];jbad=[];base={a['id']:a for a in jean[0]['party']}
for i,row in enumerate(jean):
 for a in row['party']:
  statuses=[s for s in a['statuses'] if s['id']=='CONS_JEAN_2'];expectedround=[None,2,2,2,1,None][i];expectedmult=1 if expectedround is None else 1.15
  if (len(statuses)!=(0 if expectedround is None else 1) or (statuses and statuses[0]['rounds']!=expectedround) or not same(a['atk'],base[a['id']]['atk']*expectedmult) or a['spd']!=base[a['id']]['spd']+(0 if expectedround is None else 10) or a['maxHp']!=base[a['id']]['maxHp'] or not same(a['def'],base[a['id']]['def']) or a['shields']!=base[a['id']]['shields']):jbad.append({'step':i,'id':a['id']})
ck('native_jean_c2_refresh_no_stack_and_expiry_record',len(jean)==6 and not jbad,{'states':len(jean),'actorStates':sum(len(x['party']) for x in jean),'bad':jbad})
diluc=o['dilucC2Probe'];d0=base['MOND_DILUC']['atk'];dbad=[]
for i,d in enumerate(diluc):
 stack=min(i+1,3)
 if d['hpLost']!=1 or d['status']['stacks']!=stack or d['status']['mods']['atk']['pct']!=15*stack or d['status']['rounds']!=2 or not same(d['atk'],d0*(1+.15*stack)):dbad.append(i+1)
ck('native_diluc_c2_three_stack_cap_record',len(diluc)==4 and not dbad,{'hits':len(diluc),'bad':dbad})
settle=o['actualNativeSettlementProbe']
ck('native_defeat_settlement_clears_battle_effects_record',settle['consStatusesCleared'] and settle['settled']['receipt']['victory'] is False and all(not a['consStatuses'] and not a['shields'] for a in settle['cleanNewBattle']) and not settle['settled']['playerStatuses'] and not settle['settled']['jeanStatuses'] and not settle['settled']['dilucStatuses'])

review=(DIR/'REVIEW_KO.md').read_text();observe=(DIR/'observe.cjs').read_text();supplement=(DIR/'supplement.cjs').read_text()
scope_phrases=['모든 효과를 모든 조건에서 전투 테스트했다는 의미는 아니다','획득시간','격리된 상태 검사','캠페인 난이도 승패 통계와 섞지 않았다','CRPG','전원 Lv25를 단정하지 않았다']
ck('report_definition_fixture_and_campaign_scopes_distinguished',all(p in review for p in scope_phrases) and 'Definition/handler coverage is not proof' in o['method']['certainty'] and 'not a legitimate campaign victory or public action test' in settle['method'])
ck('scripts_do_not_run_campaign_comparison',not re.search(r'\b(?:campaign|play)\(',observe) and not re.search(r'\b(?:campaign|play)\(',supplement))
warnings += [
 '43 C6 fixtures, 344 stat records and isolated C2 hook/damage/roundEnd/settlement probes are separate diagnostic scopes, not additional full-campaign battle samples.',
 'Literal fx.t handler coverage proves a named branch exists; it does not prove all conditions, nested fx, interactions or every constellation works correctly in combat.',
 '119 DB READY owners are not 119 currently playable companions; current final support metadata records 43, with 76 future unsupported owners.',
 'The observed Jean/Diluc isolated effects do not establish the difficulty or exact party metadata of a user screenshot.',
 'The script validates save state with validateSave(clone(runtime.s)); it does not independently test a fresh serialize-deserialize disk round trip or acquisition grind.',
 'No new native runtime experiment was run in this QA; mathematical rechecks use saved records and current read-only source.',
 'The 1.1 rarity comparison formula is idealized without authored-base rounding. Actual character ratios include Math.round(base*1.1), authored bases and equipment.'
]
after={str(p):meta(p) for p in INPUTS+[BASE]};ck('all_original_input_hashes_and_mtimes_unchanged',before==after)
summary={'stats':len(stats),'uniqueStatRecords':len(set(actual_keys)),'companions':len(ids),'fourStar':rarities[4],'fiveStar':rarities[5],'levels':levels,'c6FixtureCount':len(fixtures),'c6UnlockReceipts':unlockcount,'baseTalent':4,'actualEffectiveTalent':{'na':4,'e':7,'q':7},'nameEffectSets':46,'topLevelEffectTypes':22,'currentSupported':len(supported),'dbReadyOwnerCount':len(ready),'futureUnsupportedReady':len(ready-set(ids)),'campaignBattleSamplesAddedByThisDataset':0}
result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':not errors,'method':'Read-only independent static source/hash, saved-record arithmetic and definition/scope QA. No new native experiment, product/DB/git/repository document mutations.','inputs':before,'inputsAfter':after,'summary':summary,'checks':checks,'errors':errors,'warnings':warnings,'limitations':warnings,'sourceBefore':baseline,'sourceCurrent':current}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'output':str(OUT),'passed':result['passed'],'errors':errors,'summary':summary,'statMismatchPreview':statbad[:3]},ensure_ascii=False,indent=2))
