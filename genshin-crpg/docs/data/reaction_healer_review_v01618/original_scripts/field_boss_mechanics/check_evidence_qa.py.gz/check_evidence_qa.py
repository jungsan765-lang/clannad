from pathlib import Path
import json,hashlib,math,datetime
F=Path('/tmp/crpg_reaction_plan/field_boss_mechanics')
R=Path('/workspace/scratch/a62414469990/crpg-v01618-work/genshin-crpg')
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def state(p):return {'mtime':p.stat().st_mtime,'bytes':p.stat().st_size,'sha256':sha(p)}
files=sorted(F.glob('*'));files=[p for p in files if p.is_file()];before={p.name:state(p) for p in files}
D=load(F/'native_mechanics.json');S=load(F/'summary.json');G=load(F/'growth_curve.json');M=load(F/'manifest.json');H=load(F/'source_hashes.json');B=load(F/'baseline_comparison.json');I=load(F/'native_mechanics_initial_harness.json')
counts={'bossStats':len(D['stats']),'isolatedMoves':len(D['moves']),'schedules':len(D['schedules']),'checks':len(D['checks']),'passed':sum(c['passed'] for c in D['checks']),'failed':sum(not c['passed'] for c in D['checks'])}
prior=load('/tmp/crpg_healer_audit/source_before.json');changed={k:sha(R/k) for k,v in prior.items() if sha(R/k)!=v}
manifestErrors=[name for name,entry in M['files'].items() if sha(F/name)!=entry['sha256'] or (F/name).stat().st_size!=entry['bytes']]
statsErrors=[];growthErrors=[];moveErrors=[];scheduleErrors=[];transitions=[]
statKeys=set()
for st in D['stats']:
 statKeys.add(st['id']);summary=next(x for x in S['stats'] if x['id']==st['id']);pre=st['beforeFinalGrowth'];post=st['afterFinalGrowth']
 percent=(post['atk']/pre['atk']-1)*100
 if not math.isclose(percent,summary['atkChangePercent'],rel_tol=1e-12,abs_tol=1e-12):statsErrors.append({'id':st['id'],'field':'ATK percent'})
 if summary['beforeHp']!=pre['maxHp'] or summary['beforeAtk']!=pre['atk'] or summary['hp']!=post['maxHp'] or summary['atk']!=post['atk'] or summary['level']!=post['level']:statsErrors.append({'id':st['id'],'field':'summary stats'})
 if not math.isclose(post['maxHp']/pre['maxHp'],st['ratioFinalToPre']['hp']) or not math.isclose(post['atk']/pre['atk'],st['ratioFinalToPre']['atk']):statsErrors.append({'id':st['id'],'field':'ratio'})
 transitions.append({'id':st['id'],'configuredEnemyLevel':st['configuredLevel'],'playerFixtureLevel':st['profile']['level'],'sameBattlePreGrowthHP':pre['maxHp'],'finalHP':post['maxHp'],'hpChangePercent':100*(post['maxHp']/pre['maxHp']-1),'sameBattlePreGrowthATK':pre['atk'],'finalATK':post['atk'],'atkChangePercent':percent,'finalRawDEF':post['def'],'finalEffectiveDEF':post['effectiveDef']})
caps=[10,20,30,40,50,55,60]
HP=[[5,900],[8,2100],[10,2800],[12,3200],[15,3600],[20,4300],[25,5200],[30,6500],[40,9000],[50,12500],[60,17000]]
ATK=[[5,180],[8,650],[10,870],[12,940],[15,1060],[20,1250],[25,1440],[30,1750],[40,2500],[50,3500],[60,4900]]
def budget(points,l):
 if l<=points[0][0]:return points[0][1]
 for i,(end,n) in enumerate(points[1:],1):
  if l<=end:
   start,value=points[i-1];return value+(n-value)*(l-start)/(end-start)
 return points[-1][1]
def rounded(x):return math.floor(x+.5)
gkeys=set()
for row in G['rows']:
 l=row['level'];i=['일반','정예','강적','보스'].index(row['grade']);p=next(j for j,c in enumerate(caps) if c>=l);h=1+.13*(l-1)+.002*(l-1)**2;a=1+.12*(l-1)+.003*(l-1)**2
 hpParty=1 if i==3 else 2+.025*l;atkParty=1 if i==3 else min(1.7,1+.2*(l-1));hb=ab=1
 if l>4 and i!=3:
  hb=1+(budget(HP,l)/(105*h*(1+.16*p)*(2+.025*l))-1)*[1,.7,.3][i]
  ab=1+(budget(ATK,l)/(24*h*(1+.18*p)*math.sqrt(a)*min(1.7,1+.2*(l-1)))-1)*[1,.8,.35][i]
 expected={'hp':rounded([105,340,900,3000][i]*h*(1+.16*p)*hpParty*hb),'atk':rounded([24,38,52,65][i]*h*(1+.18*p)*math.sqrt(a)*atkParty*ab),'def':rounded([20,28,35,42][i]*a)}
 expected['effectiveDef']=expected['def']/math.sqrt(a)
 for k,v in expected.items():
  if not math.isclose(row[k],v,rel_tol=1e-12,abs_tol=1e-8):growthErrors.append({'level':l,'grade':row['grade'],'field':k,'recorded':row[k],'recomputed':v})
 gkeys.add((l,row['grade']))
for row in D['moves']:
 if row['immediateDamage']!=sum(p['damage'] for p in row['direct']) or row['hazardDamageFirst']!=sum(p['damage'] for p in row['hazardEndFirst']):moveErrors.append({'id':row['id'],'move':row['move'],'field':'packet total'})
 for packet in row['direct']:
  target=next((a for a in row['allies'] if a['source']==packet['targetId']),None)
  if target is None:moveErrors.append({'id':row['id'],'move':row['move'],'field':'target identity'});continue
  expected=packet['damage']/target['maxHp']*100
  if not math.isclose(expected,packet['hpPercent'],abs_tol=1e-10):moveErrors.append({'id':row['id'],'move':row['move'],'field':'HP percentage'})
for row in D['schedules']:
 for label,k in [('totalAdvertisedActions','advertisedActions'),('totalDirectPackets','directPackets'),('totalDirectDamage','directDamage'),('totalHazardDamage','hazardDamage')]:
  if row[label]!=sum(t[k] for t in row['turns']):scheduleErrors.append({'id':row['id'],'field':label})
 if len(row['turns'])!=8:scheduleErrors.append({'id':row['id'],'field':'eight isolated turns'})
checks={c['id']:c['evidence'] for c in D['checks'] if c['passed']}
soft=checks['boss_push_control_is_soft_damage_and_speed_not_lock_or_charge_cancel'];four=checks['cryo_four_direct_hits_do_not_end_prematurely'];last=checks['cryo_revival_roundend_before_native_end_field_tick']
boundary={'softControlledRatio':soft['controlledSum']/soft['baseSum'],'softLocked':soft['locked'],'softChargeStillBLAST':soft['next']=='BLAST','softSpeedDelta':soft['after']['effectiveSpd']-soft['before']['effectiveSpd'],'coreBeforeFourthHP1':all(t['hp']==1 for t in four['timeline'][:3]),'coreFourthHP0':four['timeline'][3]['hp']==0,'coreBreakCountOne':four['coreBreaks']==1,'lastCoreFirstENDHits':last['timeline'][0]['revival']['hits'],'lastSecondENDRevivalExpired':last['timeline'][1]['revival'] is None,'notActualBattleWins':True}
after={p.name:state(p) for p in files}
qa={'checkedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':'1e1b2442b53d42873d29556898f5f612d52d0c7a','readOnlyProduct':True,'inputsBefore':before,'inputsStableDuringCheck':before==after,'inputsAfter':after,'counts':counts,'countsAgreeWithRawSummaryManifest':counts==D['counts']==S['counts']==M['counts'],'uniqueBossStats':len(statKeys),'uniqueMoves':len({(x['id'],x['move']) for x in D['moves']}),'uniqueSchedules':len({x['id'] for x in D['schedules']}),'uniqueGrowthRows':len(gkeys),'growthRows':len(G['rows']),'manifestErrors':manifestErrors,'statsErrors':statsErrors,'growthFormulaErrors':growthErrors,'movePacketOrPercentErrors':moveErrors,'scheduleAggregationErrors':scheduleErrors,'transitions':transitions,'boundaryChecks':boundary,'sourceSubset119':{'count':len(D['sourceBefore']),'beforeAfterEqual':D['sourceBefore']==D['sourceAfter']==H['before']==H['after'],'currentAllEqual':all(sha(R/k)==v for k,v in D['sourceBefore'].items())},'product233':{'count':len(prior),'allEqual':not changed,'changed':changed},'remoteComparedSubset':{'count':B['comparedFiles'],'allMatch':B['allMatch']},'initialHarness':{'counts':I['counts'],'superseded':M['files']['native_mechanics_initial_harness.json']['superseded'],'finalReplacedFailures':True},'interpretationWarnings':['Pre-growth versus final is two stages of the SAME current0.16.18 battle setup, not a0.16.17/0.16.18 version comparison.','Player fixtureLv25 does not imply all bossesLv25: each boss retains configured native level18–56.','RawDEF and effectiveDEF are different units. EffectiveDEF is rawDEF/sqrt(adCurve(level)).','11/11 are mechanic assertions.26moves and9rotations reset/restore allies and step native methods; none is a complete legal battle win or win-rate denominator.','Midpoint RNG removes crit/miss variance for isolated packet observations; full repeat battles require separate evidence.','Superseded initial harness output had10/11passed. It is preserved for provenance and is not a product-bug result or final failure.']}
out=Path('/tmp/crpg_reaction_plan/field_boss_mechanics_evidence_qa.json');out.write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'growthRows':len(G['rows']),'errors':len(manifestErrors)+len(statsErrors)+len(growthErrors)+len(moveErrors)+len(scheduleErrors),'stable':before==after,'product233Equal':not changed,'output':str(out)},ensure_ascii=False))
