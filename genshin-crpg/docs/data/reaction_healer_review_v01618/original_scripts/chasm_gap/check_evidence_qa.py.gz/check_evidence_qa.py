import collections, datetime, gzip, hashlib, json, pathlib
B=pathlib.Path('/tmp/crpg_reaction_plan/chasm_gap');ROOT=pathlib.Path('/workspace/scratch/a62414469990/crpg-v01618-work/genshin-crpg')
OUT=pathlib.Path('/tmp/crpg_reaction_plan/chasm_gap_evidence_qa.json')
def meta(p):
 s=p.stat();return {'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
S=json.loads((B/'summary.json').read_text());M=json.loads((B/'manifest.json').read_text())
inputs={name:meta(B/name) for name in M['files']};inputs['manifest.json']=meta(B/'manifest.json')
extraPaths=[ROOT/'tools/audit_protagonist_v01618.cjs',pathlib.Path('/tmp/crpg_reaction_plan/dendro/campaign.cjs'),pathlib.Path('/tmp/crpg_reaction_plan/dendro/probe.cjs')]
extraInputs={str(p):meta(p) for p in extraPaths}
errors=[];checks=collections.Counter();warnings=[]
def ck(ok,label,ctx=None):
 checks[label]+=1
 if not ok:errors.append({'check':label,'context':ctx})
with gzip.open(B/'native_all.json.gz','rt',encoding='utf8') as f:R=json.load(f)
ck(R['metadataCorrections']==S['metadataCorrections'],'metadata correction preserved')
ck(len(R['files'])==len(R['outputs'])==10,'ten completed campaign files excludes pilot')
ck(not any('_pilot' in f for f in R['files']),'pilot excluded from aggregate')
rows=[];byFile=[];seen=[];damageStats=collections.Counter();damageSamples=[];nativeWinAndSequence=[];groups={};cohorts={'base':collections.Counter(),'supplemental':collections.Counter()}
lookup={(r['file'],r['name'],r['map'],r['enhance'],r['talent'],r['seed']):r for r in S['rows']}
for filename,x in zip(R['files'],R['outputs']):
 with gzip.open(B/filename,'rt',encoding='utf8') as f:original=json.load(f)
 ck(x==original,'compressed aggregate matches individual native file',filename)
 base=not any(z in filename for z in ['extra10','native_extra','fourC6']);cohort='base' if base else 'supplemental'
 ft={'file':filename,'cohort':cohort,'conditions':len(x['rows']),'battles':sum(len(r['battles']) for r in x['rows']),'wins':sum(r['wins'] for r in x['rows']),'losses':sum(r['losses'] for r in x['rows']),'errors':len(x['errors']),'seeds':sorted({r['seed'] for r in x['rows']}),'baseTalents':sorted({r['talent'] for r in x['rows']}),'enhancements':sorted({r['enhance'] for r in x['rows']}),'teamNames':sorted({r['name'] for r in x['rows']})};byFile.append(ft)
 for r in x['rows']:
  k=(r['name'],r['map'],r['enhance'],r['talent'],r['seed'],json.dumps(r['constellations'],sort_keys=True));seen.append(k);sr=lookup[(filename,*k[:5])]
  rows.append(r);seq=[bool(b['result'].get('victory')) for b in r['battles']]
  nativeWins=sum(seq);nativeLosses=sum(not v for v in seq)
  ck(nativeWins==r['wins']==sr['wins'] and nativeLosses==r['losses']==sr['losses'],'native H.play victory actual row summary counts',k)
  ck(seq==[bool(b['victory']) for b in r['battles']]==[bool(b['victory']) for b in sr['battles']],'native summary victory sequence',k)
  ck(all(bool(b['last']['win'])==bool(b['result']['victory']) for b in r['battles']),'finishBattle native win agrees public reward',k)
  ck(len(seq)<=3 and (not nativeLosses or seq[-1] is False),'stop at first defeat maxthree',k)
  ck(nativeLosses<=1 and all(seq[:-1]),'no victory after defeat',k)
  first=bool(seq and seq[0]);three=(seq==[True,True,True]);ck((r['wins']==3)==three,'threeNoInn requires three native wins',k)
  ck(sr['baseMatrix']==base,'base versus supplemental metadata',k)
  ck(r['lodgingMora']==0,'no lodging in native campaign',k)
  ck(all(g['level']==25 and g['phase']==2 and g['talentCap']==4 for g in r['growth'].values()),'actual initial Lv25 phase2 talentcap4',k)
  ck(all(set(t.values())=={r['talent']} for t in r['talents'].values()),'actual saved base talent',k)
  ck(all(a['enhance']==r['enhance'] for a in r['equipment']),'actual enhancement',k)
  nativeWinAndSequence.append({'file':filename,'key':k,'nativeWinSequence':seq,'firstWin':first,'threeNoInn':three})
  for metric,value in [('conditions',1),('battles',len(seq)),('wins',nativeWins),('losses',nativeLosses),('firstWins',first),('threeNoInn',three)]:cohorts[cohort][metric]+=value
  gkey=(r['map'],r['name'],cohort);g=groups.setdefault(gkey,{'map':gkey[0],'name':gkey[1],'cohort':cohort,'conditions':0,'firstWins':0,'threeNoInn':0,'wins':0,'losses':0,'rounds':[]})
  g['conditions']+=1;g['firstWins']+=first;g['threeNoInn']+=three;g['wins']+=nativeWins;g['losses']+=nativeLosses;g['rounds']+=[b['rounds'] for b in r['battles']]
  for i,b in enumerate(r['battles']):
   sb=sr['battles'][i]
   ck(b['before']==sb['before'] and b['after']==sb['after'] and b['result']==sb['result'],'summary native state/result preserve',(*k,i))
   if i:ck(b['before']==r['battles'][i-1]['after'],'HP XP carry without intermediate heal',(*k,i))
   allies={a['id'] for a in b['initial']['actors'] if a['side']=='ALLY'}
   ck(len(allies)==4,'native four ally slots',(*k,i))
   alog=[l for l in b['last']['log'] if l.get('targetId') in allies]
   incomingLabel='damageLogTotalToAllies' if 'damageLogTotalToAllies' in sb else 'hpDamageToAllies'
   ck(sb[incomingLabel]==sum(l.get('damage',0) for l in alog),'reported incoming is native damage log sum',(*k,i))
   ck(sb['shieldsAbsorbedToAllies']==sum(l.get('absorbed',0) for l in alog),'reported shield absorption log sum',(*k,i))
   for l in alog:
    if 'damage' not in l:continue
    damageStats['incomingNativeDamageLogs']+=1;damageStats['nativeDamageLogSum']+=l['damage']
    pre=next((a['hp'] for a in l.get('presentationActorsBefore',[]) if a['id']==l.get('targetId') and 'hp' in a),l.get('hpBefore'))
    if pre is None:damageStats['logsMissingAnyPreHp']+=1;continue
    damageStats['logsWithAnyPreHp']+=1;damageStats['sumBoundedByPreHp']+=min(l['damage'],pre)
    if l['damage']>pre:
     damageStats['nativeDamageGreaterThanPreHpPackets']+=1
     if len(damageSamples)<6:damageSamples.append({'file':filename,'condition':k,'fight':i,'round':l['round'],'nativeDamageLog':l['damage'],'preHp':pre,'hpAfter':l.get('hpAfter')})
   ck(all(a['constellation']==r['constellations'].get(a['source'],0) for a in sb['allies']),'effective initial constellation levels from native source',(*k,i))
ck(len(seen)==len(set(seen))==160,'160 unique full condition keys')
ck(len(lookup)==160,'summary rows keys unique')
expected={'conditions':160,'battles':257,'wins':128,'losses':129,'errors':0,'firstWins':58,'threeNoInn':31}
recomputed={k:sum(v[k] for v in cohorts.values()) for k in ['conditions','battles','wins','losses','firstWins','threeNoInn']};recomputed['errors']=sum(len(x['errors']) for x in R['outputs'])
ck(recomputed==S['totals']==expected,'independently recomputed completed total counts')
ck(cohorts['base']['conditions']==132 and cohorts['supplemental']['conditions']==28,'base132 supplemental28 separate denominators')
ck(S['groups']==list(groups.values()),'all 15 group counts round sequences recomputed')
talentWitness=[]
for name in ['routes_and_seeds.json','scattered_seeds.json']:
 d=json.loads((B/name).read_text())
 for row in d['talents']:
  base=row['base'];a=next(x for x in row['actors'] if x['id']=='PLAYER_CUSTOM')
  ck((a['cons'],a['growth']['phase'],a['levels']['na'],a['levels']['e'],a['levels']['q'])==(3,2,base,base,base+3),'actual Traveler C3 Q not E and phase2 witness',(name,base))
  talentWitness.append({'file':name,'base':base,'effectiveNaEQ':[a['levels'][k] for k in ['na','e','q']],'phase':a['growth']['phase']})
for f,v in M['files'].items():ck(inputs[f]['bytes']==v['bytes'] and inputs[f]['sha256']==v['sha256'],'manifest every original artifact hash',f)
ck(S['fingerprints']==M['baseFingerprint']==sorted({x['fingerprint'] for x in R['outputs']}),'all native fingerprints same')
baseline=json.loads(pathlib.Path('/tmp/crpg_healer_audit/source_before.json').read_text());product={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in baseline}
ck(len(product)==233 and product==baseline,'233 source DB baseline hash unchanged')
helper=(ROOT/'tools/audit_protagonist_v01618.cjs').read_text();campaign=(B/'campaign.cjs').read_text();dendro=pathlib.Path('/tmp/crpg_reaction_plan/dendro/campaign.cjs').read_text()
ck('Math.max(0,hp-t.hp)+Math.max(0,shield-' in helper,'outgoing H.observe is outer HP shield net delta')
ck('hpDamageToAllies' not in campaign and 'const meter=H.observe(E,r)' in campaign,'chasm campaign uses inherited outgoing net meter')
ck("if(e.reaction&&Object.hasOwn(e,'damage'))" in dendro,'Dendro reaction damage sums native log fields not purified reaction extra')
after={name:meta(B/name) for name in inputs};ck(after==inputs,'all original input hashes mtimes sizes unchanged');ck({str(p):meta(p) for p in extraPaths}==extraInputs,'helper Dendro sources hashes mtimes unchanged')
warnings=[
 'Base matrix132 and supplemental28 are distinct. Supplemental seeds/gear/constellations were purpose-selected and cannot be pooled into unbiased win-rate averages or a general character rarity verdict.',
 'Native H.play reward victory, finishBattle win, raw victory flags and first/three-win sequences agree. These outcomes do not depend on the damage accounting caveat.',
 'H.observe ownDamage/allyDamage records per-applyDamage outer HP net decline plus shield decline; heal-before-hit can change net loss. Chasm/Dendro campaign outgoing totals have no packet-to-native-log/pre-hit HP reconciliation comparable to boss C0 QA. Do not label those totals verified true damage or infer exact damage superiority from them.',
 'Chasm damageLogTotalToAllies (formerly hpDamageToAllies) is instead an unbounded sum of native log.damage, not the outgoing net meter. Native log.damage can include overkill; this summary did not cap every packet to actual pre-hit HP. The provided bounded-log diagnostic is not a replacement fully reconciled damage meter.',
 'Dendro reaction damage includes full hit for amplification/additive reactions and separate packet for transformative reactions; the totals cannot all be called pure reaction bonus damage.',
 'Actual initial Lv25/phase2 is observed; old legal phase1 prose and Traveler C3 E+3 prose were corrected in metadata. Traveler native C3 buffs Q; initial companion levels/gear are diagnostic assumptions, not a recovered user save.',
 'Native XP and level-up full healing carry between fights. Three wins without inn therefore does not imply three fights without any native healing.',
 'Public WAIT60min is a natural encounter witness, not measured travel or farming time. Diagnostic ownership/gear/acquisition time excluded.',
 'Pilot compressed data are preserved as an artifact but excluded from completed aggregate counts.',
 'No new runtime experiments or product, DB, Git, or documentation changes.'
]
out={'generatedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qaScope':'read-only native victory/condition metadata/counts and metric limitations','inputFiles':inputs,'additionalMeterSourceInputs':extraInputs,'inputsUnchanged':inputs==after,'checks':dict(checks),'recomputedTotals':recomputed,'cohorts':{k:dict(v) for k,v in cohorts.items()},'perFileScopes':byFile,'nativeVictorySequences':nativeWinAndSequence,'travelerActualTalentWitnesses':talentWitness,'damageAccountingDiagnostic':dict(damageStats),'overkillSamples':damageSamples,'errors':errors,'warnings':warnings,'passed':not errors}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'output':str(OUT),'errorCount':len(errors),'errors':errors[:8],'counts':recomputed,'cohorts':out['cohorts'],'damageDiagnostic':dict(damageStats),'checks':sum(checks.values())},ensure_ascii=False,indent=2))
