import subprocess, pathlib, concurrent.futures, time
p=pathlib.Path('/tmp/crpg_reaction_plan/chasm_gap')
jobs=[(m,g) for m in ['MAP_CHASM_DEEP','MAP_CHASM_SURFACE','MAP_LY_DETAIL_CHASM_GATE'] for g in [3,6]]
def run(j):
 m,g=j; s=time.time()
 with open(p/f'campaign_{m}_{g}.log','w') as f:
  c=subprocess.run(['node',str(p/'campaign.cjs'),m,str(g)],stdout=f,stderr=subprocess.STDOUT)
 return {'map':m,'enhance':g,'code':c.returncode,'seconds':round(time.time()-s,1)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:
 for r in e.map(run,jobs): print(r,flush=True)
