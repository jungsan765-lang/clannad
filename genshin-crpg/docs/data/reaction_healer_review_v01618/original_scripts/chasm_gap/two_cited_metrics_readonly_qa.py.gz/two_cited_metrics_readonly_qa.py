import datetime, gzip, hashlib, json, pathlib
B=pathlib.Path('/tmp/crpg_reaction_plan'); ROOT=pathlib.Path('/workspace/scratch/a62414469990/crpg-v01618-work/genshin-crpg')
OUT=B/'two_cited_metrics_qa.json'
paths=[B/'chasm_gap/two_enemy_snapshot.json',B/'chasm_gap/campaign_MAP_CHASM_DEEP_6_native_extra.json.gz',B/'field_boss_repeat/summary.json',B/'field_boss_repeat/e6.json',B/'chasm_gap/campaign_MAP_CHASM_DEEP_6.json.gz',B/'chasm_gap/summary.json',pathlib.Path('/tmp/crpg_healer_audit/source_before.json')]
def meta(p):
 s=p.stat();return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns}
inputs={str(p):meta(p) for p in paths};errors=[];checks=[]
def ck(ok,label,details=None):
 checks.append({'check':label,'passed':bool(ok),'details':details})
 if not ok:errors.append({'check':label,'details':details})
def damage_log_stats(b,initial,lastlog):
 allies={a['source'] for a in initial if a['side']=='ALLY'};logs=[l for l in lastlog if 'damage' in l and l.get('targetId') in allies];ret={'packets':len(logs),'logDamageTotal':sum(l['damage'] for l in logs),'boundedHpDamageTotal':0,'overkillPackets':0,'missingPreHpPackets':0,'perActor':{a:0 for a in allies}}
 for l in logs:
  pre=next((a['hp'] for a in l.get('presentationActorsBefore',[]) if a['id']==l.get('targetId') and 'hp' in a),l.get('hpBefore'))
  if pre is None:ret['missingPreHpPackets']+=1;continue
  n=min(l['damage'],pre);ret['overkillPackets']+=l['damage']>pre;ret['boundedHpDamageTotal']+=n;ret['perActor'][l['targetId']]+=n
 return ret
def balance(initial,end,after,damage,heals):
 out=[]
 for a in initial:
  if a['side']!='ALLY':continue
  id=a['source'];e=next(x for x in end if x['source']==id);f=next(x for x in after if x['owner']==id);d=damage['perActor'][id];h=heals.get(id,0)
  out.append({'id':id,'initialCombatHp':a['hp'],'initialCombatMaxHp':a['maxHp'],'damage':d,'healing':h,'beforeRewardHp':e['hp'],'beforeRewardMaxHp':e['maxHp'],'afterRewardHp':f['hp'],'afterRewardMaxHp':f['maxHp'],'residualInitialMinusDamagePlusHealMinusEnd':a['hp']-d+h-e['hp'],'rewardHpDelta':f['hp']-e['hp'],'beforeLevel':e['level'],'afterLevel':f['level']})
 return out
snapshot=json.loads(paths[0].read_text());ss=next(r for r in snapshot['rows'] if (r['name'],r['enhance'],r['talent'],r['seed'])==('SCREENSHOT_C232',6,4,318012461))
with gzip.open(paths[1],'rt',encoding='utf8') as f:C=json.load(f)
cr=next(r for r in C['rows'] if (r['name'],r['enhance'],r['talent'],r['seed'])==('SCREENSHOT_C232',6,4,318012461));cb=cr['battles'][0];ci=cb['initial']['actors'];cl=cb['last']['log'];cd=damage_log_stats(cb,ci,cl)
ch={a['source']:sum(l.get('heal',0) for l in cl if l.get('targetId')==a['source']) for a in ci if a['side']=='ALLY'};cba=balance(ci,cb['last']['actors'],cb['after'],cd,ch);chsum=sum(ch.values());cnet=sum(a['hp'] for a in cb['before'])-sum(a['hp'] for a in cb['after'])
ck(cd['logDamageTotal']==cd['boundedHpDamageTotal']==ss['actualHpLossInDamageLogs']==24606,'cited chasm HPdamage24606 verified',cd)
ck(chsum==cb['heal']==ss['actualHeals']==16976,'cited chasm actual healing16976 native log matches')
ck(cnet==ss['netHpLossAfterReward']==7630==24606-16976,'cited chasm settlement netloss7630')
ck(cd['overkillPackets']==cd['missingPreHpPackets']==0,'cited chasm logs no overkill no missing actual preHp')
ck(all(a['residualInitialMinusDamagePlusHealMinusEnd']==0 for a in cba),'cited chasm every actor HPbalance0',cba)
ck(all(a['rewardHpDelta']==0 and a['beforeLevel']==a['afterLevel']==25 for a in cba),'cited chasm no reward heal revive levelup or maxHpclip loss')
ck(all(a['hp']>0 for a in cb['last']['actors'] if a['side']=='ALLY') and all(a['hp']>0 for a in cb['after']),'cited chasm all four alive before after settlement')
ck(not cb['result'].get('protagonistRevived') and ss.get('nativeProtagonistRevivedHp') is None,'cited chasm no protagonist settlement revival')
ck('LIYUE_XINGQIU' not in {a['source'] for a in ci},'cited chasm no Xingqiu prehit healing concern')
ck(cb['victory'] and cb['result']['victory'] and cb['last']['win'],'cited chasm native public victory')
ck(cr['lodgingMora']==0 and not any(k in cr for k in ['recoveries','recoveryFailure']),'cited chasm no postbattle recovery')
ck(cr['constellations']=={'PLAYER_CUSTOM':3,'MOND_DILUC':2,'LIYUE_GANYU':0,'MOND_JEAN':2},'cited chasm actual C3 C2 C0 C2 saved fixture')
F=json.loads(paths[2].read_text());raw=json.loads(paths[3].read_text())
cond=lambda r:(r['team'],r['enhance'],r['talentMode'],r['seed'])==('FIVE_DEFENSIVE',6,'MAX',717)
sr=next(r for r in F['conditions'] if cond(r));sb=sr['battles'][0];fr=next(r for r in raw['rows'] if cond(r));fb=fr['battles'][0];fi=fb['initial'];fl=fb['lastLog'];fd=damage_log_stats(fb,fi,fl)
fh={a['source']:sum(h['effective'] for h in fb['heals'] if h['target']==a['source']) for a in fi if a['side']=='ALLY'};fhl={a['source']:sum(l.get('heal',0) for l in fl if l.get('targetId')==a['source']) for a in fi if a['side']=='ALLY'};fba=balance(fi,fb['beforeReward'],fb['after'],fd,fh)
actual={'rounds':fb['rounds'],'actualHpDamage':fd['boundedHpDamageTotal'],'shieldAbsorbed':sum(p['shieldAbsorbed'] for p in fb['incomingPackets']),'actualHealing':sum(fh.values())};expected={'rounds':13,'actualHpDamage':9315,'shieldAbsorbed':33428,'actualHealing':9669}
ck(actual=={'rounds':8,'actualHpDamage':0,'shieldAbsorbed':12177,'actualHealing':354},'initial request boss path corrected; separately verified boss actual tuple')
ck(actual=={'rounds':sb['rounds'],'actualHpDamage':sb['hpDamage'],'shieldAbsorbed':sb['shieldAbsorbed'],'actualHealing':sb['actualHeal']},'actual boss tuple native raw agrees final summary')
ck(fd['overkillPackets']==fd['missingPreHpPackets']==0,'actual boss logs no overkill no missing preHp')
ck(fh==fhl,'actual boss heal packets match native logs',{'hook':fh,'log':fhl})
ck(all(a['residualInitialMinusDamagePlusHealMinusEnd']==0 for a in fba),'actual boss every actor HPbalance0',fba)
ck(all(a['hp']>0 for a in fb['beforeReward']) and all(a['hp']>0 for a in fb['after']),'actual boss all alive before after settlement')
ck(not fb['reward'].get('protagonistRevived'),'actual boss no protagonist settlement revival')
ck(all(a['rewardHpDelta']<=0 and a['beforeLevel']==a['afterLevel']==25 for a in fba),'actual boss no reward heal or levelup; slot3 clip separately')
ck('LIYUE_XINGQIU' not in {a['source'] for a in fi},'actual boss no Xingqiu prehit healing concern')
ck(fb['win'] and fb['reward']['victory'],'actual boss native public victory')
ck(fr['battles'][1]['before']==fb['after'],'actual boss next battle begins without intermediate recovery')
matches=[{'key':{k:r[k] for k in ['team','enhance','talentMode','seed']},'fight':b['number'],'rounds':b['rounds'],'hpDamage':b['hpDamage'],'shieldAbsorbed':b['shieldAbsorbed'],'actualHeal':b['actualHeal']} for r in F['conditions'] for b in r['battles'] if b['hpDamage']==9315 or b['shieldAbsorbed']==33428 or b['actualHeal']==9669]
with gzip.open(paths[4],'rt',encoding='utf8') as f:T=json.load(f)
tr=next(r for r in T['rows'] if (r['name'],r['enhance'],r['talent'],r['seed'])==('FIVE_DEFENSIVE',6,4,717));tb=tr['battles'][0];ti=tb['initial']['actors'];tl=tb['last']['log'];td=damage_log_stats(tb,ti,tl)
th={a['source']:sum(l.get('heal',0) for l in tl if l.get('targetId')==a['source']) for a in ti if a['side']=='ALLY'};tba=balance(ti,tb['last']['actors'],tb['after'],td,th)
tshield=sum(l.get('absorbed',0) for l in tl if l.get('targetId') in {a['source'] for a in ti if a['side']=='ALLY'})
tactual={'rounds':tb['rounds'],'actualHpDamage':td['boundedHpDamageTotal'],'shieldAbsorbed':tshield,'actualHealing':sum(th.values())}
ck(tactual==expected,'corrected second cited Chasm three husks tuple matches native original',{'expected':expected,'actual':tactual})
ck(td['overkillPackets']==td['missingPreHpPackets']==0,'corrected second chasm native logs no overkill no missing preHp')
ck(sum(th.values())==tb['heal']==9669,'corrected second chasm native actual healing counters logs agree')
ck(all(a['residualInitialMinusDamagePlusHealMinusEnd']==0 for a in tba),'corrected second chasm every actor HPbalance0',tba)
ck(all(a['hp']>0 for a in tb['last']['actors'] if a['side']=='ALLY') and all(a['hp']>0 for a in tb['after']),'corrected second chasm all alive before after settlement')
ck(not tb['result'].get('protagonistRevived'),'corrected second chasm no settlement protagonist revival')
ck(all(a['beforeLevel']==a['afterLevel']==25 and a['rewardHpDelta']<=0 for a in tba),'corrected second chasm no settlement heal or levelup')
ck(sum(a['rewardHpDelta'] for a in tba)==-354 and sum(a['hp'] for a in tb['before'])==sum(a['hp'] for a in tb['after']),'corrected second chasm slot3 clip354 and post reward netloss0')
ck('LIYUE_XINGQIU' not in {a['source'] for a in ti},'corrected second chasm no Xingqiu')
ck(tb['victory'] and tb['result']['victory'] and tb['last']['win'],'corrected second chasm native public victory')
ck(tr['battles'][1]['before']==tb['after'] and tr['lodgingMora']==0,'corrected second chasm no intermediate or final forced recovery')
ck(tr['constellations']=={} and all(a.get('consLevel',0)==0 for a in ti if a['side']=='ALLY'),'corrected second chasm C0 actual fixture')
enemies=[a for a in ti if a['side']=='ENEMY'];ck(len(enemies)==3 and all(a['level']==56 for a in enemies),'corrected second chasm native Lv56 three husks')
SS=json.loads(paths[5].read_text());tsr=next(r for r in SS['rows'] if r['file']=='campaign_MAP_CHASM_DEEP_6.json.gz' and (r['name'],r['enhance'],r['talent'],r['seed'])==('FIVE_DEFENSIVE',6,4,717));tsb=tsr['battles'][0]
ck(tsb['damageLogTotalToAllies']==td['logDamageTotal']==9315 and tsb['shieldsAbsorbedToAllies']==33428 and tsb['heal']==9669 and tsb['rounds']==13,'corrected second chasm final summary preserved cited metrics')
baseline=json.loads(paths[-1].read_text());product={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in baseline};ck(len(product)==233 and product==baseline,'all 233 product DB source baseline unchanged')
after={str(p):meta(p) for p in paths};ck(inputs==after,'cited original inputs unchanged hash mtime')
out={'generatedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':not errors,'method':'Read-only isolated-row native logs/counters/HP conservation/settlement QA; no new experiments or mutations of any original evidence/product/documents/DB/Git.','requestPathCorrection':{'initialRequestedSecondPath':'field_boss_repeat FIVE_DEFENSIVE +6 MAX seed717','clarifiedSecondPath':'chasm_gap Lv56 THREE_HUSK FIVE_DEFENSIVE +6 baseTalent4 seed717 first fight','reason':'Parent corrected the dataset path; numeric tuple belongs to Chasm, not Cryo Hypostasis. This is a request-context correction, not a source-data/citation numeric error.'},'inputs':inputs,'inputsUnchanged':inputs==after,'checks':checks,'errors':errors,'chasm':{'condition':{'name':'SCREENSHOT_C232','enhance':6,'talent':4,'seed':318012461},'battle':1,'rounds':cb['rounds'],'damage':cd,'healsByTarget':ch,'actualHealing':chsum,'netHpLossAfterReward':cnet,'actorBalances':cba,'result':cb['result']},'chasmThreeHusks':{'condition':{'name':'FIVE_DEFENSIVE','enhance':6,'baseTalent':4,'seed':717},'battle':1,'citedExpected':expected,'actualFinal':tactual,'damage':td,'healsByTarget':th,'actorBalances':tba,'postRewardNetHpLoss':sum(a['hp'] for a in tb['before'])-sum(a['hp'] for a in tb['after']),'slot3HpClippingLoss':354,'result':tb['result']},'separatelyConfirmedBoss':{'condition':{'team':'FIVE_DEFENSIVE','enhance':6,'talentMode':'MAX','seed':717},'battle':1,'actualFinal':actual,'damage':fd,'healsByTarget':fh,'actorBalances':fba,'reward':fb['reward'],'rewardHpDelta':fb['rewardHpDelta']},'warnings':['Initial second-case dataset path was corrected by the parent. Both requested numerical citations are now validated under their actual Chasm source paths.','The corrected Chasm three-husk fight actual healing9669 covers incoming HPdamage9315 plus slot3 combat-only maxHP bonus354; settlement clips354 and leaves all raw persistent HP full.','The separately confirmed Cryo Hypostasis first fight heals slot3 combat-only maxHP bonus354 then settlement clips354. It is a separate baseline, not the cited Chasm 13-round example.','The dangerous two-husk Chasm cited single battle has four alive and no revival/reward healing. Entire condition still later records2wins1loss; do not call it a three-win no-inn success.','No protagonist settlement revival, level-up heal or postbattle recovery contributed to either cited Chasm first battle.','Existing official QA originals are preserved unchanged. This file only updates the newly requested isolated-citation QA after path clarification.']}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'out':str(OUT),'passed':out['passed'],'errors':errors,'chasmDangerous':{'damage':cd['boundedHpDamageTotal'],'healing':chsum,'netAfterReward':cnet,'rounds':cb['rounds']},'chasmThreeHusks':tactual,'separateCryoBoss':actual},ensure_ascii=False,indent=2))
