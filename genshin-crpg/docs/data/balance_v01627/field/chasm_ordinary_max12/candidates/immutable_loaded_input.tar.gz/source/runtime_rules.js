/* HOUSE_RULE_V1: explicit geometry and missing values; source coefficients remain unchanged. */
(function(root){'use strict';
const api=root.CRPGRuntime,P=api.Runtime.prototype;
const old=Object.fromEntries(['cardTargets','cardSupport','cardReason','executeCard','damage','applyDamage','newRound','roundEnd','tickFields','aiTurn','addField','combatCards','validateSave','combatSupportReport'].map(k=>[k,P[k]]));
const E={PYRO:'불',HYDRO:'물',CRYO:'얼음',ELECTRO:'번개',ANEMO:'바람',GEO:'바위',DENDRO:'풀',PHYSICAL:'물리'},el=x=>E[x]||x||'물리',copy=x=>JSON.parse(JSON.stringify(x)),clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const st=(a,id)=>a?.statuses?.find(s=>s.id===id&&(!Number.isFinite(s.rounds)||s.rounds>0));
const newCards=new Set(['MOND_BENNETT_E','MOND_VENTI_E','MOND_DAHLIA_E','MOND_KLEE_E','MOND_MONA_E','MOND_ROSARIA_E','MOND_SUCROSE_E','MOND_SUCROSE_Q']);
P.cardTargets=function(a,c){if(c.id==='MOND_DAHLIA_E')return this.s.runtime.actors.filter(t=>t.hp>0&&(t.side===a.side||this.hasAirAccess(a,t,c.range)));return old.cardTargets.call(this,a,c);};
P.cardSupport=function(c){return newCards.has(c.id)?(c.ready?'':'이 카드의 실행 정의가 준비되지 않았습니다.'):old.cardSupport.call(this,c);};
P.combatSupportReport=function(){return old.combatSupportReport.call(this).map(c=>({...c,constraint:['MOND_JEAN_E','MOND_JEAN_Q','MOND_MONA_Q'].includes(c.id)?null:c.constraint}));};
P.combatSize=function(a){return a.size||(/^(MON_MITACHURL_|MON_MITA_)/.test(a.source)?'LARGE':({일반:'SMALL',정예:'MEDIUM',강적:'LARGE',보스:'BOSS'}[a.grade]||(a.side==='ALLY'?'MEDIUM':'SMALL')));};
P.initCombatPositions=function(){const b=this.s.runtime;if(!b)return;let enemy=0;for(const a of b.actors){const i=enemy;if(a.side==='ENEMY')enemy++;if(!a.position)a.position={x:a.side==='ALLY'?2:Math.min(5,3+Math.floor(i/4)),y:a.side==='ALLY'?clamp((a.slot||1)-1,0,3):i%4};a.size=this.combatSize(a);a.facing=a.facing||(a.side==='ALLY'?1:-1);}b.rulesVersion=1;};
P.combatDistance=function(a,b){return Math.abs((a.position?.x??2)-(b.position?.x??2))+Math.abs((a.position?.y??0)-(b.position?.y??0));};
P.combatOrderedTargets=function(a,eligible,target){const picked=eligible.find(t=>t.id===target)||eligible[0];return picked?[picked,...eligible.filter(t=>t!==picked).sort((x,y)=>this.combatDistance(picked,x)-this.combatDistance(picked,y)||this.s.runtime.actors.indexOf(x)-this.s.runtime.actors.indexOf(y))]:[];};
P.nearbyTargets=function(anchor,side,max=Infinity){return this.s.runtime.actors.filter(t=>t.side===side&&t.hp>0&&this.combatDistance(anchor,t)<=1).sort((a,b)=>this.combatDistance(anchor,a)-this.combatDistance(anchor,b)||this.s.runtime.actors.indexOf(a)-this.s.runtime.actors.indexOf(b)||a.id.localeCompare(b.id)).slice(0,max);};
// A native elemental body is immune to that damage element, including reaction packets.
// Match the monster source rather than nativeAura: temporary infusions never confer immunity.
P.hasElementImmunity=function(target,element){const native=this.nativeSlimeElement(target);return !!native&&native===el(element);};
P.moveCombatActor=function(a,to,o={}){this.initCombatPositions();if(!o.forced&&st(a,'LIFTED'))return false;const next={x:clamp(Math.round(to.x),0,5),y:clamp(Math.round(to.y),0,3)};if(next.x===a.position.x&&next.y===a.position.y)return false;const from=copy(a.position);a.position=next;this.s.runtime.log.push({actor:a.name,movement:{from,to:next},reason:o.cause||'위치 이동'});this.resolveCombatContact(a);return true;};
P.displaceCombatActor=function(source,target,pull=false,o={}){this.initCombatPositions();if(pull&&this.combatDistance(source,target)===0)return false;const dx=source.position.x-target.position.x,dy=source.position.y-target.position.y,dir=pull?1:-1,to=copy(target.position);if(Math.abs(dx)>=Math.abs(dy))to.x+=(Math.sign(dx)||-target.facing)*dir;else to.y+=Math.sign(dy)*dir;return this.moveCombatActor(target,to,{...o,forced:true});};
P.applyCombatControl=function(source,target,kind,o={}){if(target.hp<=0||o.element&&this.hasElementImmunity(target,el(o.element)))return false;const size=this.combatSize(target);if(o.bossImmune&&size==='BOSS')return false;if(size==='BOSS'||size==='LARGE'&&kind==='FREEZE')return !!this.addCombatStatus(target,'BOSS_CONTROL',1);if(size==='LARGE'&&['PULL','PUSH','LIFT'].includes(kind))return false;let chance=o.chance??100;if((target.statuses||[]).some(s=>s.staggerResist)||st(target,'THUNDERWOLF'))chance*=.5;if(chance<100&&this.die()>chance)return false;if(kind==='FREEZE')return !!this.addCombatStatus(target,'STATUS_FREEZE',1,{coexist:['물','얼음']});else if(kind==='LIFT'){if(!this.addCombatStatus(target,'LIFTED',1))return false;target.nextScorePenalty=Math.max(10,target.nextScorePenalty||0);}else if(kind==='PULL'||kind==='PUSH')return this.displaceCombatActor(source,target,kind==='PULL',{cause:kind==='PULL'?'끌어당김':'밀치기'});return true;};
P.combatActionLocked=function(a){return !!st(a,'STATUS_FREEZE')||!!st(a,'ILLUSORY_BUBBLE')&&a.grade==='일반';};
P.onCombatTurnStart=function(a){this.resolveCombatContact(a);};
P.newRound=function(){this.initCombatPositions();const b=this.s.runtime;for(const f of b.fields)if(f.kind==='OZ'&&f.repositionRound!==b.round){const a=b.actors.find(x=>x.id===f.actor),target=b.actors.filter(x=>x.side!==f.side&&x.hp>0).sort((x,y)=>this.combatDistance(a,x)-this.combatDistance(a,y))[0];if(target)f.position=copy(target.position);f.repositionRound=b.round;}return old.newRound.call(this);};
P.auraList=function(t){if(!t.auras){t.auras=t.aura&&['불','물','번개','얼음','풀'].includes(el(t.aura))?[{element:el(t.aura),rounds:2,createdRound:this.s.runtime.round}]:[];}return t.auras;};
P.syncAura=function(t){t.aura=this.auraList(t).map(a=>a.element).join(' · ')||null;};
P.setAura=function(t,element){element=el(element);if(!['불','물','번개','얼음','풀'].includes(element)||this.hasElementImmunity(t,element))return;const a=this.auraList(t).find(x=>x.element===element);if(a)Object.assign(a,{rounds:2,createdRound:this.s.runtime.round});else t.auras.push({element,rounds:2,createdRound:this.s.runtime.round});this.syncAura(t);};
P.reactionBase=function(a){return (25+12*a.level)*(st(a,'REACTION_BOOST')?1.15:1);};
// Blunt is an attack property, not every charged attack or every skill wielding a claymore.
P.combatBluntHit=function(a,element,o={}){
 if(o.blunt===false)return false;
 if(el(element)==='바위'||o.blunt||/둔중|\bBLUNT\b/.test((o.tags||[]).join(' ')))return true;
 const kind=this.premiumHitKind?.(a,o),weapon=this.consWeaponType?.(a);
 if(kind==='na'&&(weapon==='양손검'||a?.source==='MOND_KLEE'))return true;
 if(['LIYUE_GAMING_E','MOND_KLEE_E','MOND_DILUC_E','MOND_EULA_E','MOND_EULA_Q'].includes(o.card))return true;
 return a?.source==='MOND_AMBER'&&o.sourceKind==='OBJECT'&&/^SUMMON:BUNNY:/.test(o.presentationActorId||'');
};
P.reactionFor=function(t,element,o={}){element=el(element);
 // In this existing single-reaction model, a confirmed blunt hit spends Frozen before elemental amplification.
 if(st(t,'STATUS_FREEZE')&&(element==='바위'||o.blunt||/둔중|\bBLUNT\b/.test((o.tags||[]).join(' ')))){const shatter=this.tables['37_ELEMENTAL_REACTION_DB'].get('RX_SHATTER');if(shatter)return [...shatter];}
 if(o.noAura)return null;
 const auras=this.auraList(t).map(x=>x.element),candidates=[];for(const r of this.combatRows('37_ELEMENTAL_REACTION_DB')){if(!String(r[0]).startsWith('RX_')||/LUNAR|STELLAR/.test(r[0])||r[0]==='RX_SHATTER')continue;const aura=auras.find(x=>String(r[2]).split('/').includes(x)&&x!==element);let match=aura&&String(r[3]).split('/').includes(element);if(['RX_AGGRAVATE','RX_SPREAD'].includes(r[0]))match=!!st(t,'QUICKEN')&&String(r[3]).split('/').includes(element);if(['RX_HYPERBLOOM','RX_BURGEON'].includes(r[0]))match=String(r[3]).split('/').includes(element)&&this.s.runtime.fields.some(f=>f.kind==='DENDRO_CORE'&&!f.done&&this.combatDistance(t,f)===0);if(match)candidates.push(Object.assign([...r],{previousAura:aura}));}return candidates.sort((a,b)=>Number(b[12])-Number(a[12]))[0]||null;};
P.reactionSupportReason=function(){return '';};
P.applyCombatAura=function(a,t,element,o={}){element=el(element);if(this.hasElementImmunity(t,element)&&!this.nativeSlimeElement(t))return null;const rx=o.reaction===undefined?this.reactionFor(t,element,o):o.reaction;
 // Hydro may consume the Pyro aura by Vaporize, but the old Burning tick must also stop.
 if(element==='물'&&st(t,'STATUS_BURN'))t.statuses=t.statuses.filter(s=>s.id!=='STATUS_BURN');
 if(!rx){if(t.hp>0)this.setAura(t,element);return null;}const base=this.reactionBase(a),b=this.s.runtime;const rootChain=!this._reactionChain;if(rootChain)this._reactionChain={visited:new Set(),queue:[]};const chain=this._reactionChain;chain.visited.add(t.id);
 try{
  if(rx[20]==='CONSUME_EXISTING_AURA'){t.auras=this.auraList(t).filter(x=>x.element!==rx.previousAura);this.syncAura(t);}else if(rx[20]==='COEXIST_STATE'){this.setAura(t,element);}
  const packet=(target,n,element2)=>this.applyDamage(a,target,n,{element:el(element2),reaction:rx[0],sourceKind:'REACTION'});
  const neighbors=()=>this.nearbyTargets(t,t.side);
  switch(rx[0]){
   case'RX_OVERLOADED':for(const q of neighbors()){packet(q,base*2,'불');if(q.grade==='일반'||q.grade==='보스')this.applyCombatControl(a,q,'PUSH',{element:'불'});}break;
   case'RX_SUPERCONDUCT':for(const q of neighbors()){packet(q,base*.5,'얼음');if(q.hp>0)this.addCombatStatus(q,'PHYS_VULN',2);}break;
   case'RX_SWIRL':for(const q of neighbors()){if(rx.previousAura!=='물'||q===t)packet(q,base*.6,rx.previousAura);if(q!==t&&q.hp>0&&!chain.visited.has(q.id)){chain.visited.add(q.id);chain.queue.push({source:a,target:q,element:rx.previousAura});}}break;
   case'RX_CRYSTALLIZE':this.shield(a,base,'RX_CRYSTALLIZE',3,{element:rx.previousAura,damageMultipliers:{[rx.previousAura]:.4}});break;
   case'RX_MELT_PYRO':t.statuses=t.statuses.filter(s=>s.id!=='STATUS_FREEZE');break;
   case'RX_FROZEN':this.applyCombatControl(a,t,'FREEZE',{element:'얼음'});break;
   case'RX_SHATTER':t.statuses=t.statuses.filter(s=>s.id!=='STATUS_FREEZE');packet(t,base*3,'물리');break;
   case'RX_BURNING':case'RX_ELECTROCHARGED':if(t.hp>0)this.addCombatStatus(t,rx[22],2,{reactionTick:base*Number(rx[7]),actor:a.id,element:rx[5],reaction:rx[0],coexist:rx[0]==='RX_BURNING'?['풀','불']:['물','번개']});break;
   case'RX_QUICKEN':if(t.hp>0)this.addCombatStatus(t,'QUICKEN',2);break;
   case'RX_BLOOM':this.addCombatObject('DENDRO_CORE',a,2,{position:copy(t.position),reactionBase:base,sourceCardId:o.card});break;
   case'RX_HYPERBLOOM':case'RX_BURGEON':{const core=b.fields.find(f=>f.kind==='DENDRO_CORE'&&!f.done&&this.combatDistance(t,f)===0);if(core){core.done=true;const targets=rx[0]==='RX_HYPERBLOOM'?b.actors.filter(q=>q.hp>0&&q.side!==a.side).sort((x,y)=>this.combatDistance(core,x)-this.combatDistance(core,y)).slice(0,1):this.nearbyTargets(core,t.side);for(const q of targets)packet(q,base*3,'풀');}break;}
  }
  b.log.push({actor:a.name,target:t.name,reaction:rx[0],reactionName:rx[1],text:rx[1]+' 반응'});
  if(rootChain)while(chain.queue.length){const next=chain.queue.shift();this.applyCombatAura(next.source,next.target,next.element,{sourceKind:'SPREAD'});}
  return rx;
 }finally{if(rootChain)this._reactionChain=null;}
};
P.applyDamage=function(a,t,amount,d={}){if(!t||t.hp<=0)return 0;const element=el(d.element);if(this.hasElementImmunity(t,element)){this.s.runtime.log.push({actor:a.name,target:t.name,damage:0,immune:true,element,reason:'원소 면역'});return 0;}const bubble=amount>0?st(t,'ILLUSORY_BUBBLE'):null;let mult=(bubble?1.3:1)*(st(t,'OMEN')?1.15:1)*(!d.skipSourceModifiers&&st(a,'BOSS_CONTROL')?.9:1);if(element==='물리'&&st(t,'PHYS_VULN'))mult*=1.25;if(element==='바람'&&st(t,'ANEMO_VULN'))mult*=1.05;if(d.sourceKind?.startsWith('REACTION'))mult*=this.combatDamageMultiplier(a,t,element,d);if(bubble)t.statuses=t.statuses.filter(s=>s!==bubble);t.lastDamagePacket=Math.round(Math.max(0,amount*mult));if(this.captureAndriusPrimaryPacket)this.captureAndriusPrimaryPacket(a,t,t.lastDamagePacket,d);const n=old.applyDamage.call(this,a,t,amount*mult,{...d,element});if(bubble&&t.hp>0){const owner=this.s.runtime.actors.find(x=>x.id===bubble.actor);if(owner){this.damage(owner,t,.9,'물',{range:'전장',sourceKind:'BUBBLE',card:'MOND_MONA_Q'});if(t.hp>0)this.addCombatStatus(t,'OMEN',2);}}return n;};
// New battles preserve late-level incoming pressure without changing DEF-based
// attacks, shields, healing or outgoing damage. Unmarked saved fights retain 100.
// Scripted formation defense keeps its separately tuned waves and body-attack budget.
P.combatDefenseBase=function(a,t){const b=this.s.runtime,normal=b?.storyConfig?.objective?.kind!=='PROTECT_FORMATION',incoming=b?.defenseRevision===1&&normal&&a?.side==='ENEMY'&&t?.side==='ALLY',outgoing=b?.enemyBalanceRevision===1&&!b.abyss&&!b.raid&&normal&&a?.side==='ALLY'&&t?.side==='ENEMY'&&!t.fieldStructure;return incoming||outgoing?100+5*Math.max(0,(Number(a.level)||1)-35):100;};
P.damage=function(a,t,k,element='PHYSICAL',o={}){const b=this.s.runtime;if(!t||t.hp<=0)return false;this.initCombatPositions();
 const bunny=!o.ignoreTaunt&&this.baronBunnyIntercept?.(a,t,o);if(bunny){const proxy={id:'SUMMON:BUNNY:'+bunny.actor,name:'토끼 백작',side:bunny.side,hp:bunny.hp,maxHp:bunny.maxHp||bunny.hp,atk:0,def:bunny.def||0,spd:0,crit:0,critDmg:0,hit:100,eva:0,resist:0,level:1,range:'근접',grade:'소환물',statuses:[],shields:[],position:bunny.position};b.log.push({actor:a.name,actorId:a.id,target:'토끼 백작',targetId:proxy.id,taunted:true,text:a.name+'의 단일 공격이 토끼 백작에게 유도되었다.',round:b.round,actionSequence:b.actionSequence||0});const landed=this.damage(a,proxy,k,element,{...o,ignoreTaunt:true});bunny.hp=proxy.hp;if(bunny.hp<=0)this.explodeBunny(bunny);return landed;}
 element=el(element);if(this.hasElementImmunity(t,element)&&!this.nativeSlimeElement(t)){this.applyDamage(a,t,0,{element,...(o.presentationActorId?{presentationActorId:o.presentationActorId,presentationActorName:o.presentationActorName}:{} )});return false;}const range=o.range||a.range;if(!this.hasAirAccess(a,t,range))return false;if(st(t,'LEVITATION')&&range==='근접'&&!a.airborne){b.log.push({actor:a.name,target:t.name,miss:true,reason:'부양'});return false;}const shieldEva=Math.max(0,...(t.shields||[]).map(x=>x.evaBonus||0));if(!o.sureHit&&this.die()>clamp(this.combatStat(a,'hit')-this.combatStat(t,'eva')-shieldEva+10+(o.hitBonus||0),65,98)){b.log.push({actor:a.name,target:t.name,miss:true});return false;}
 const attach=!o.noAura&&['불','물','얼음','번개','바람','바위','풀'].includes(element),rx=this.reactionFor(t,element,{...o,blunt:this.combatBluntHit(a,element,o)});
 let mult=(rx?.[17]==='AMPLIFY'?Number(rx[6]):1)*(t.slotDamageMultiplier||1)*(t.guard?.5:1)*(st(t,'FALLBACK_DEFENSE')?.damageMultiplier||1),raw=this.combatStat(a,o.stat||'atk')*k+(o.rawAdd||0);
 if(t.airborne&&!['원거리','전장','대공','부유'].includes(range)&&!st(a,'LEVITATION')&&(st(a,'STATUS_TACTICAL_LEVITATION')||st(a,'EXPLICIT_ACCESS_TO_BOSS_DVALIN')))mult*=.85;
 if(st(a,'SKILL_COEFF')&&o.card&&!o.card.startsWith('PLAYER_BASIC'))raw*=1.3;
 let multiplierOptions=o;
 if(rx?.[17]==='ADDITIVE'){
  // Direct talent damage scales once. Aggravate/Spread's level-based addition does not scale with the talent.
  const kind=a.side==='ALLY'&&a.source?this.premiumHitKind?.(a,o):null;
  if(kind)raw*=this.premiumTalentMultiplier(a,kind);
  raw+=this.reactionBase(a)*Number(rx[7]);multiplierOptions={...o,skipTalentMultiplier:true};
 }
 if(st(a,'DILUC_INFUSION')&&element==='불')mult*=1.2;if((a.cicinCount||0)>0&&element==='번개'&&!o.sourceKind)mult*=1.1;mult*=this.combatDamageMultiplier(a,t,element,multiplierOptions);const crit=!o.noCrit&&this.die()<=this.combatStat(a,'crit'),defenseBase=this.combatDefenseBase(a,t),amount=Math.max(1,raw*defenseBase/(defenseBase+this.combatStat(t,'def'))*(crit?1+this.combatStat(a,'critDmg')/100:1)*mult*(.95+.1*this.random()));this.applyDamage(a,t,amount,{element,critical:crit,reaction:rx?.[0]||null,card:o.card||null,sourceKind:o.sourceKind||null,...(o.presentationActorId?{presentationActorId:o.presentationActorId,presentationActorName:o.presentationActorName}:{} )});if(attach||rx?.[0]==='RX_SHATTER')this.applyCombatAura(a,t,element,{...o,reaction:rx});if((a.cicinCount||0)>0&&!o.sourceKind&&t.hp>0)this.damage(a,t,.2,'번개',{range:'원거리',sourceKind:'ASSIST'});return true;};
P.addField=function(kind,a,rounds,extra={}){const f=old.addField.call(this,kind,a,rounds,extra);this.initCombatPositions();f.position=f.position||copy(a.position);if(!f.id){this.s.runtime.objectSequence=(this.s.runtime.objectSequence||0)+1;f.id=this.s.runtime.id+':F'+this.s.runtime.objectSequence;}f.sourceCardId=f.sourceCardId||this._executingCard||({ICE:'MOND_KAEYA_Q',OZ:'MOND_FISCHL_E',ROSE:'MOND_LISA_Q',FROST_MIST:'MOND_DIONA_Q',BOMBARD:'MOND_KLEE_Q'}[kind]);return f;};
P.addCombatObject=function(kind,a,rounds,extra={}){this.initCombatPositions();const b=this.s.runtime;b.objectSequence=(b.objectSequence||0)+1;const f={id:b.id+':O'+b.objectSequence,kind,actor:a.id,side:a.side,position:copy(a.position),rounds,createdRound:b.round,...extra};b.fields.push(f);
 if(kind==='DENDRO_CORE'){const cores=b.fields.filter(x=>x.kind==='DENDRO_CORE'&&!x.done);while(cores.length>5)this.detonateCombatObject(cores.shift());b.fields=b.fields.filter(x=>!x.done);}
 return f;};
P.detonateCombatObject=function(f){if(f.done)return;f.done=true;const b=this.s.runtime,a=b.actors.find(x=>x.id===f.actor);if(!a)return;const side=a.side==='ALLY'?'ENEMY':'ALLY',targets=f.kind==='PHANTOM'?b.actors.filter(t=>t.side===side&&t.hp>0).sort((x,y)=>this.combatDistance(f,x)-this.combatDistance(f,y)).slice(0,3):this.nearbyTargets(f,side);for(const t of targets){if(f.kind==='DENDRO_CORE')this.applyDamage(a,t,f.reactionBase*2,{element:'풀',reaction:'RX_BLOOM',sourceKind:'REACTION'});else this.damage(a,t,f.kind==='PHANTOM'?.9:.3,f.kind==='PHANTOM'?'물':'불',{range:'원거리',card:f.sourceCardId,sourceKind:'OBJECT'});}};
P.resolveCombatContact=function(a){const b=this.s.runtime;if(!b||a.hp<=0)return;for(const f of b.fields.slice()){if(f.done||!f.position||this.combatDistance(a,f)!==0)continue;const owner=b.actors.find(x=>x.id===f.actor);if(!owner)continue;if(f.kind==='KLEE_MINE'&&a.side!==f.side)this.detonateCombatObject(f);if(f.kind==='MIST_TRACE'){f.done=true;if(a.side===f.side)this.addCombatStatus(a,'LEVITATION',1);else for(const t of [a,...this.nearbyTargets(a,a.side).filter(t=>t!==a)].slice(0,3))this.damage(owner,t,1,'HYDRO',{range:'원거리',card:'MOND_DAHLIA_E',sourceKind:'OBJECT'});}}};
P.aiTurn=function(a,targets){const f=this.s.runtime.fields.find(f=>f.kind==='PHANTOM'&&!f.done&&f.side!==a.side&&f.hp>0);if(f&&a.grade!=='보스'){const best=this.actorCards(a).filter(c=>!this.cardReason(a,c)).sort((x,y)=>y.weight-x.weight)[0];if(!best||/^DMG:ATK\*[\d.]+:[A-Z]+:/.test(best.script)){const proxy={id:f.id,source:'PHANTOM',name:'물의 허영',side:f.side,hp:f.hp,maxHp:f.maxHp,def:f.def,eva:0,position:f.position,statuses:[],shields:[]};const m=best?.script.match(/^DMG:ATK\*([\d.]+):([A-Z]+):/);this.damage(a,proxy,m?Number(m[1]):.65,m?.[2]||a.element,{range:best?.range||a.range,card:best?.id});if(best&&m)a.cooldowns[best.id]=best.cooldown;f.hp=proxy.hp;if(f.hp<=0)this.detonateCombatObject(f);return;}}return old.aiTurn.call(this,a,targets);};
P.executeCard=function(a,c,target,branch){this.initCombatPositions();const prior=this._executingCard;this._executingCard=c.id;try{const b=this.s.runtime,allies=b.actors.filter(t=>t.side===a.side&&t.hp>0),eligible=b.actors.filter(t=>t.side!==a.side&&t.hp>0&&this.hasAirAccess(a,t,c.range)),picked=eligible.find(t=>t.id===target)||eligible[0],targets=picked?[picked,...eligible.filter(t=>t!==picked).sort((x,y)=>this.combatDistance(picked,x)-this.combatDistance(picked,y))]:[],hit=(t,k,e,o={})=>this.damage(a,t,k,e,{range:c.range,card:c.id,hitBonus:c.hit,tags:String(c.row[25]||'').split('/'),...o});
 const custom=newCards.has(c.id)||['MOND_JEAN_E','MOND_JEAN_Q','MOND_MONA_Q','MOND_FISCHL_Q'].includes(c.id);
 if(!custom){const result=old.executeCard.call(this,a,c,target,branch);if(c.id==='MOND_VENTI_Q')for(const t of targets)if(this.combatSize(t)==='SMALL')this.applyCombatControl(a,t,'LIFT',{element:'바람'});return result;}
 switch(c.id){
 case'MOND_BENNETT_E':if(picked){hit(picked,.5,'불');if(this.die()<=99)this.displaceCombatActor(picked,a,false,{cause:'스킬 반동'});}break;
 case'MOND_VENTI_E':if(picked){const k=picked.source==='BOSS_SIGNORA'?.45:picked.source==='MOND_VENTI'?1.35:.9;hit(picked,k,'바람');if(picked.hp>0)this.addCombatStatus(picked,'ANEMO_VULN',1);}for(const t of allies)this.addCombatStatus(t,'LEVITATION',1);break;
 case'MOND_DAHLIA_E':this.addField('MIST_TRACE',a,2,{position:copy((b.actors.find(t=>t.id===target)||picked||a).position),sourceCardId:c.id});break;
 case'MOND_KLEE_E':for(const t of targets.slice(0,3))hit(t,.9,'불');for(let i=0;targets.length&&i<3;i++)this.addCombatObject('KLEE_MINE',a,2,{position:copy(targets[i%Math.min(3,targets.length)].position),sourceCardId:c.id});break;
 case'MOND_MONA_E':{const prior=b.fields.find(f=>f.kind==='PHANTOM'&&f.actor===a.id&&!f.done);if(prior)this.detonateCombatObject(prior);b.fields=b.fields.filter(f=>!f.done);this.addField('PHANTOM',a,2,{hp:Math.floor(a.maxHp*.25),maxHp:Math.floor(a.maxHp*.25),def:this.combatStat(a,'def'),position:copy((picked||a).position),sourceCardId:c.id});for(const t of targets.filter(t=>t.grade==='보스'))this.applyCombatControl(a,t,'TAUNT',{element:'물'});break;}
 case'MOND_ROSARIA_E':if(picked){let attached=hit(picked,.45,'얼음');hit(picked,1,'얼음',{noAura:attached});if(!['LARGE','BOSS'].includes(this.combatSize(picked))){const to={x:picked.position.x-picked.facing,y:picked.position.y};if(to.x>=0&&to.x<6&&this.moveCombatActor(a,to,{cause:'후방 이동'}))this.addCombatStatus(a,'ROSARIA_BEHIND',2,{mods:{crit:{flat:12}}});}}break;
 case'MOND_SUCROSE_E':{const log=b.log.length;for(const t of targets.slice(0,4)){this.applyCombatControl(picked,t,'PULL',{element:'바람'});this.applyCombatControl(a,t,'LIFT',{element:'바람'});hit(t,1,'바람');}if(b.log.slice(log).some(x=>x.reaction==='RX_SWIRL'))for(const t of allies)this.addCombatStatus(t,'REACTION_BOOST',2);break;}
 case'MOND_SUCROSE_Q':this.addField('WIND_SPIRIT',a,2,{position:copy((picked||a).position),absorbed:null,sourceCardId:c.id});break;
 case'MOND_JEAN_E':for(const t of targets.slice(0,3)){this.applyCombatControl(a,t,'PULL',{bossImmune:true,element:'바람'});hit(t,1.2,'바람');this.applyCombatControl(a,t,'PUSH',{bossImmune:true,element:'바람',chance:this.combatSize(t)==='SMALL'?100:50});}break;
 case'MOND_JEAN_Q':{const h=this.combatHealingBudget();for(const t of allies)this.heal(t,this.combatStat(a,'atk')*h.jeanQRatio+h.jeanQFlat,a.name);for(const t of targets.slice(0,4)){this.applyCombatControl(a,t,'PUSH',{element:'바람'});hit(t,.7,'바람');}this.addField('DANDELION',a,2,{sourceCardId:c.id,healTargetCount:1,healTicks:0,healMaxTicks:h.jeanFieldTicks});break;}
 case'MOND_MONA_Q':for(const t of targets.slice(0,4)){this.setAura(t,'물');this.addCombatStatus(t,'ILLUSORY_BUBBLE',1,{actor:a.id});if(t.grade==='보스')this.applyCombatControl(a,t,'BUBBLE',{element:'물'});}break;
 case'MOND_FISCHL_Q':for(const t of targets.slice(0,4)){hit(t,1.1,'번개');this.moveCombatActor(a,t.position,{cause:'밤의 환영'});}this.addField('OZ',a,99,{name:'오즈',asset:'summon_oz.webp',sourceCardId:c.id,summonTurns:2,summonTicks:0});break;
 }
 a.cooldowns[c.id]=c.cooldown;b.log.push({actor:a.name,card:c.id,cardName:c.name});
 }finally{this._executingCard=prior;}};
P.tickFields=function(timing){const b=this.s.runtime;if(!b)return;const ice=b.fields.filter(f=>f.kind==='ICE'&&!f.done);if(timing==='START'){for(const f of ice){const a=b.actors.find(t=>t.id===f.actor&&t.hp>0);if(a&&b.round>f.createdRound)for(const t of this.nearbyTargets(a,a.side==='ALLY'?'ENEMY':'ALLY',3))this.damage(a,t,.45,'얼음',{range:'근접',card:'MOND_KAEYA_Q',sourceKind:'FIELD'});}for(const f of ice)f.kind='ICE_PROCESSED';}
 try{old.tickFields.call(this,timing);}finally{for(const f of ice)f.kind='ICE';}
 if(timing!=='END')return;
 for(const f of b.fields.slice()){
  if(f.done)continue;const a=b.actors.find(t=>t.id===f.actor);if(!a)continue;const enemies=b.actors.filter(t=>t.side!==a.side&&t.hp>0).sort((x,y)=>this.combatDistance(f,x)-this.combatDistance(f,y));
  if(f.kind==='PHANTOM'&&a.hp>0)for(const t of enemies.slice(0,3))this.damage(a,t,.35,'물',{range:'원거리',card:f.sourceCardId,sourceKind:'FIELD'});
  if(f.kind==='WIND_SPIRIT'&&a.hp>0){const prior=f.absorbed,targets=enemies.slice(0,4);if(!prior){const aura=targets.flatMap(t=>this.auraList(t).map(x=>x.element)).find(x=>['불','물','얼음','번개'].includes(x));if(aura)f.absorbed=aura;}for(const t of targets){this.applyCombatControl({...a,position:f.position},t,'PULL',{element:'바람'});this.applyCombatControl(a,t,'LIFT',{element:'바람'});this.damage(a,t,.55,'바람',{range:'원거리',card:f.sourceCardId,sourceKind:'FIELD'});if(prior&&t.hp>0)this.damage(a,t,.2,prior,{range:'원거리',card:f.sourceCardId,sourceKind:'FIELD'});}}
  if(f.createdRound<b.round&&f.rounds<=1&&['PHANTOM','KLEE_MINE','DENDRO_CORE'].includes(f.kind))this.detonateCombatObject(f);
 }
 const dots=b.actors.flatMap(t=>(t.statuses||[]).filter(s=>s.reactionTick&&s.rounds>0).map(s=>({t,s}))),spread=[];
 for(const {t,s} of dots){if(t.hp<=0)continue;const a=b.actors.find(x=>x.id===s.actor);if(!a)continue;this.applyDamage(a,t,s.reactionTick,{element:s.element,reaction:s.reaction,sourceKind:'REACTION_DOT'});if(s.id==='STATUS_ELECTROCHARGED')for(const q of this.nearbyTargets(t,t.side).filter(x=>x!==t&&this.auraList(x).some(z=>z.element==='물')&&!st(x,'STATUS_ELECTROCHARGED')))spread.push({t:q,s});}
 for(const {t,s} of spread)if(!st(t,s.id))this.addCombatStatus(t,s.id,2,{reactionTick:s.reactionTick,actor:s.actor,element:s.element,reaction:s.reaction,coexist:s.coexist});
 b.fields=b.fields.filter(f=>!f.done);
};
P.roundEnd=function(){const b=this.s.runtime;if(!b)return false;const round=b.round,ret=old.roundEnd.call(this);if(this.s.runtime===b&&b.round>round)for(const t of b.actors){t.auras=this.auraList(t).filter(a=>{if(a.createdRound<round)a.rounds--;return a.rounds>0;});this.syncAura(t);}return ret;};
P.combatCards=function(owner){return old.combatCards.call(this,owner).map(c=>({...c,targets:c.targets.map(t=>{const a=this.combatActor(t.id);return {...t,position:a?.position,size:a&&this.combatSize(a)};})}));};
P.validateSave=function(s){old.validateSave.call(this,s);if(s.runtime){const b=s.runtime;if(b.defenseRevision!==undefined&&b.defenseRevision!==1)throw new api.RuleError('DEFENSE_VERSION','지원하지 않는 전투 방어 규칙 버전입니다.');if(b.rulesVersion&&b.rulesVersion!==1)throw new api.RuleError('RULE_VERSION','지원하지 않는 전투 규칙 버전입니다.');for(const a of b.actors){if(a.position&&(!Number.isInteger(a.position.x)||!Number.isInteger(a.position.y)||a.position.x<0||a.position.x>5||a.position.y<0||a.position.y>3))throw new api.RuleError('POSITION_SAVE','전장 위치 저장값이 잘못되었습니다.');}}return s;};
api.rulesSummary=[
 {title:'행동과 턴',text:'한 라운드의 순서는 속도 + 0~9로 정합니다. 주인공은 직접 선택하고 동료와 적은 방침에 따라 행동합니다. 재사용 대기시간은 소유자의 턴 시작에 한 번만 감소합니다.'},
 {title:'피해와 원소',text:'공격력 × 카드 계수에 방어력·치명타·피해 보정과 95~105% 변동을 적용합니다. 반응 기준값은 25 + 12 × 레벨입니다. 변환 반응은 방어력을 무시하고 기본적으로 치명타가 없습니다. 다단 공격은 한 시전에서 대상별 원소 부착을 한 번 처리합니다.'},
 {title:'위치와 제어 · 이번 규칙',text:'전장은 6×4 구역입니다. 같은 구역과 상하좌우 한 구역이 인접 범위입니다. 밀치기·당기기는 한 구역이며 충돌 추가 피해는 없습니다. 사거리와 공중 접근 규칙은 카드에 따릅니다. 일반·정예·강적·보스를 크기로 구분합니다.'},
 {title:'제어와 지속시간',text:'빙결과 일반 적의 포영은 행동을 제한합니다. 띄우기는 1라운드 이동 제한과 다음 행동점수 −10입니다. 보스의 강제 제어는 1라운드 행동점수 −20·주는 피해 −10%로 바뀌며 전용 면역이 우선합니다. 생성 라운드에는 지속시간을 줄이지 않습니다.'},
 {title:'보완한 스킬 값 · 이번 규칙',text:'벤티의 부양과 바람 피해 취약 5%는 1라운드입니다. 모나 허영의 체력은 최대 체력의 25%이며 파괴·만료 시 한 번 폭발합니다. 설탕의 흡수 추가타는 공격력의 20%로, 흡수 다음 펄스부터 적용합니다.'},
 {title:'성장과 진행',text:'최대 레벨은 20입니다. 경험치 책은 50·250·1,000 경험치를 주며 합류한 캐릭터를 지정할 수 있습니다. 이야기 중에는 이동·상자·임무 보상·제목 화면을 잠급니다. 저장·불러오기는 가능하며 지정된 자유행동 지점에서 메뉴가 열립니다.'}
];
api.houseRulesVersion='HOUSE_RULE_V1';
})(globalThis);
