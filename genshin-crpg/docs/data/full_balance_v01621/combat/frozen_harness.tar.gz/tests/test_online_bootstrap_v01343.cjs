'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const config=fs.readFileSync(path.join(root,'source/online_config.js'),'utf8');
const online=fs.readFileSync(path.join(root,'source/app_online.js'),'utf8');
const app=fs.readFileSync(path.join(root,'source/app.js'),'utf8');
const av=fs.readFileSync(path.join(root,'source/app_av.js'),'utf8');
const sw=fs.readFileSync(path.join(root,'source/sw.js'),'utf8');
const html=fs.readFileSync(path.join(root,'source/index.html'),'utf8');
const api='https://genshin-crpg-online.jungsan765.workers.dev';
assert(config.includes(api),'production API URL missing from online_config.js');
assert(online.includes("productionApi='"+api+"'"),'production fallback API missing from app_online.js');
assert(online.includes("configuredApi||(!isLocal?productionApi:'')"),'production fallback is not wired into base resolution');
assert(sw.includes("new URL('online_config.js',scopeURL).pathname"),'service worker does not special-case online_config.js');
assert(sw.includes("fetch(event.request,{cache:'no-store'})"),'online config is not fetched outside stale cache');
assert(html.indexOf('online_config.js')<html.indexOf('app_online.js'),'online config must load before online account UI');
assert(!online.includes('await localBegin(name,route)'),'logged-out begin must not fall back to a local journey');
assert(online.includes("if(!O.account||!O.token){game=null;O.active=false;persist();auth(false,true);return;}"),'begin/load guards must require an authenticated account');
assert(online.includes("busy||!loggedIn"),'title Game Start must stay disabled while logged out');
assert(online.includes("if(!O.token||!O.account){game=null;O.active=false;activeSaveSlot=null;}"),'logged-out boot must discard any in-memory local journey');
assert(online.includes("retryable:e.name!=='AbortError'"),'transport failures must distinguish safe immediate retries from timeouts');
assert(online.includes('async function actionRequest(payload)'), 'game actions must have an idempotent retry helper');
assert(online.includes("return request('/game/action',payload)"), 'action retry must reuse the exact same payload and requestId');
assert(av.includes('function startActionCover(type,params={},generic=true)'),'timed and generic saved actions must start progress feedback before the server round-trip finishes');
assert(av.includes("if(type==='COMBAT'&&!CRPGOnline.pending)GameEffects.primeCombat(type,params)"),'combat must begin visible windup while a fresh server action is being confirmed');
assert(/hitEvents\.forEach\(\(event,index\)=>this\.queueHit\([\s\S]*?\},index\*32\)\);/.test(av),'multi-hit playback must queue each hit with rapid 32ms spacing at 1x');
assert(av.includes('Math.round(hit.remaining/speed)'),'queued hit spacing must scale the unplayed interval by the current speed');
assert(av.includes('hit.remaining-(now-hit.startedAt)*hit.speed'),'queued hit spacing must preserve the remaining interval when playback is paused or its speed changes');
assert(av.includes("preservePresentation=false"),'presentation restore hook must support same-action commits without resetting playback');
assert(online.includes("install(out,{preservePresentation:true})"),'online action commits must preserve current audio/combat presentation');
assert(online.includes("LOCAL_ONLY_ACTIONS=new Set(['MENU'])"),'screen-only MENU navigation must be explicitly local-only');
assert(online.includes("game.apply({type:'MENU',screen:params.screen})"),'local-only MENU must run the same semantic menu side effects without a save transaction');
assert(app.includes("game.combatOpening?.()"),'combat UI must detect the explicit opening boundary');
assert(app.includes("act('COMBAT_BEGIN',{battle:opening.battle})"),'combat opening must expose a visible player-controlled start button');
assert(online.includes("if(O.active&&game?.s.runtime)"),'reconnecting to an unfinished battle must trigger the abandonment path');
assert(online.includes("O.execute('COMBAT_FORFEIT'"),'unfinished online battles must be forfeited on session resume');
console.log('PASS production signup, login gate, retry, responsive autosave cover and combat playback wiring');

// Progress timing and acknowledgement handoff are executed in test_action_feedback.cjs and test_online_browser.mjs.

// Reading checkpoints, optimistic reconciliation, and ordered UI prefixes are now
// executed against the real Worker and browser in test_reading_checkpoint.mjs,
// test_authoritative_flow.mjs, and test_online_browser.mjs (not source-string assertions).
const policy=online.match(/O\.savePolicy=([^;]+);/)[1];
const savePolicy=Function('LOCAL_ONLY_ACTIONS','return ('+policy+')')(new Set(['MENU']));
assert.equal(savePolicy('MENU'),'LOCAL_UI');
assert.equal(savePolicy('STORY_READ'),'READING_CHECKPOINT');
for(const type of ['EQUIP','COMBAT','FUTURE_RAID_ACTION'])assert.equal(savePolicy(type),'IMMEDIATE_SERVER');
