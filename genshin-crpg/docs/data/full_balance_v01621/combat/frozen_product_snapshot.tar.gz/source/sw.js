'use strict';
const VERSION='__CONTENT_VERSION__';
const CACHE='crpg-pack-'+VERSION;
const CORE='crpg-core-'+VERSION;
const scopeURL=new URL('./',self.location.href);
const local=(path)=>new URL(path,scopeURL).href;
// Reconstruct cached HTML: a followed redirect cannot be returned to a manual-redirect navigation.
const appEntry=u=>u.pathname===scopeURL.pathname||u.pathname===new URL('index.html',scopeURL).pathname;
async function appHTML(response){
 if(!response?.ok)return null;
 const text=await response.clone().text();
 if(!text.includes('<meta name="crpg-app" content="mond-crpg-adventure">')||!text.includes('?v='+VERSION))return null;
 const headers=new Headers(response.headers);headers.set('Content-Type','text/html; charset=utf-8');headers.delete('Content-Encoding');headers.delete('Content-Length');
 return new Response(text,{status:200,headers});
}
self.addEventListener('install',event=>{event.waitUntil((async()=>{
 const html=await appHTML(await fetch(new Request(local('./'),{cache:'reload'})));
 if(!html)throw Error('게임 진입 파일을 확인하지 못했습니다.');
 const core=await caches.open(CORE),htmlText=await html.clone().text();
 const entryAssets=[...htmlText.matchAll(/(?:src|href)="([^"]+\.(?:js|css)(?:\?[^"]*)?)"/g)].map(m=>m[1]);
 const coreAssets=[...new Set([...entryAssets,'manifest.webmanifest','offline-pack.json','NotoSansKR_subset.woff'])];
 await core.addAll(coreAssets.map(path=>new Request(new URL(path,scopeURL).href,{cache:'reload'})));
 await core.put(local('index.html'),html.clone());await core.put(local('./'),html);
 // Recovery release: activate even when a broken previous worker prevents opening the update button.
 // No client reload, IndexedDB write, or saved-game mutation occurs here.
 await self.skipWaiting();
})());});
// Retain the current release and the most recently installed predecessor for update recovery.
// Cache Storage is shared by an origin: only a core containing this registration's entry is ours.
async function pruneOldPacks(){
 const names=await caches.keys(),owned=[];
 for(const name of names){if(!name.startsWith('crpg-core-')||name===CORE)continue;const cache=await caches.open(name);if(await cache.match(local('index.html')))owned.push(name);}
 const previous=owned.at(-1);
 for(const name of owned){
  if(name===previous)continue;
  await caches.delete(name);
  const pack='crpg-pack-'+name.slice('crpg-core-'.length);
  if(!names.includes(pack))continue;
  const cache=await caches.open(pack);
  const entries=await cache.keys();
  if(entries.every(entry=>entry.url.startsWith(scopeURL.href)))await caches.delete(pack);
 }
}
// Retire the old same-origin QA wrapper even from the retained previous offline pack.
const retiredPreview=new URL('mobile-preview.html',scopeURL).pathname;
async function removeRetiredPreview(){
 for(const name of await caches.keys()){
  if(!/^crpg-(?:core|pack)-/.test(name))continue;
  const cache=await caches.open(name);
  for(const entry of await cache.keys()){const u=new URL(entry.url);if(u.origin===scopeURL.origin&&u.pathname===retiredPreview)await cache.delete(entry);}
 }
}
self.addEventListener('activate',event=>event.waitUntil((async()=>{await self.clients.claim();await removeRetiredPreview().catch(()=>{});await pruneOldPacks().catch(()=>{});})()));
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);if(event.request.method!=='GET'||u.origin!==self.location.origin)return;
 if(u.pathname===retiredPreview){event.respondWith(Promise.resolve(new Response('Not Found',{status:404,headers:{'Cache-Control':'no-store'}})));return;}
 if(event.request.mode==='navigate'){
  if(!appEntry(u))return;
  event.respondWith((async()=>{
   for(const name of [CACHE,CORE]){const cache=await caches.open(name),found=await cache.match(local('index.html')),html=await appHTML(found);if(html)return html;}
   return fetch(event.request);
  })());return;
 }
 if(u.pathname===new URL('release.json',scopeURL).pathname){event.respondWith(fetch(event.request,{cache:'no-store'}));return;}
 if(u.pathname===new URL('online_config.js',scopeURL).pathname){event.respondWith((async()=>{try{return await fetch(event.request,{cache:'no-store'});}catch{const core=await caches.open(CORE);return await core.match(event.request)||Response.error();}})());return;}
 event.respondWith((async()=>{const cache=await caches.open(CACHE),core=await caches.open(CORE),found=await cache.match(event.request)||await core.match(event.request);return found||fetch(event.request);})());
});
// Several open tabs may request the large optional pack at once. Share its download and progress.
let packFlight=null,packProgress=null;
const packPorts=new Set();
function packNews(message){packProgress=message;for(const port of packPorts)try{port.postMessage(message);}catch{packPorts.delete(port);}}
function downloadPack(port){
 packPorts.add(port);if(packFlight){if(packProgress)try{port.postMessage(packProgress);}catch{packPorts.delete(port);}return packFlight;}
 packProgress=null;
 packFlight=(async()=>{try{
  const pack=await (await fetch(local('offline-pack.json'),{cache:'no-store'})).json();if(pack.version!==VERSION)throw Error('콘텐츠 버전이 바뀌었습니다. 저장 후 앱을 다시 시작해 주세요.');
  const staging=await caches.open(CACHE);let done=0;
  for(const entry of pack.files){const response=await fetch(local(entry.path),{cache:'reload'});if(!response.ok)throw Error('콘텐츠 파일을 받지 못했습니다.');const bytes=await response.clone().arrayBuffer();const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');if(hash!==entry.sha256)throw Error('파일 검증에 실패했습니다. 다시 다운로드해 주세요.');await staging.put(local(entry.path),response);packNews({done:++done,total:pack.files.length});}
  await staging.put(local('__ready__'),new Response(JSON.stringify({version:VERSION,at:Date.now()})));packNews({ok:true,version:VERSION});
 }catch(error){packNews({error:error.message});}finally{packPorts.clear();packProgress=null;packFlight=null;}})();return packFlight;
}
self.addEventListener('message',event=>{
 if(event.data?.type==='GET_VERSION'){event.ports[0]?.postMessage({version:VERSION});return;}
 if(event.data?.type==='ACTIVATE_UPDATE'){event.waitUntil(self.skipWaiting());return;}
 if(event.data?.type==='PACK_STATUS'){event.waitUntil((async()=>{const cache=await caches.open(CACHE);if(await cache.match(local('__ready__')))event.source?.postMessage({type:'PACK_READY',version:VERSION})})());return;}
 if(event.data?.type==='DOWNLOAD_PACK'&&event.ports?.[0])event.waitUntil(downloadPack(event.ports[0]));
});
