'use strict';
// Native story-guest settlement fixtures. The actual authored preparation,
// guestSnapshots and complete finishBattle chain execute without mocked rules.
// Imposed end-of-battle HP/enemy defeat isolates accounting, not boss balance.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const copy=x=>JSON.parse(JSON.stringify(x)),GROUP='EG_ISK_M04_AA_DVALIN',OWNER='MOND_DILUC';

function fixture(env,{level=1,hp=1}={}){
 const r=new env.R(env.db);r.newGame({name:'임시 동행 성장 검사',route:'ROUTE_ISEKAI',seed:74219,saveId:'GUEST-GROWTH-V01621'});
 const cfg=r.combatStoryConfig(GROUP);assert(cfg&&cfg.guest_char_ids.includes(OWNER));assert(!r.premiumOwns(OWNER));
 Object.assign(r.s.global,{CURRENT_STORY_NODE_ID:cfg.node_id,STORY_CURSOR_NODE_ID:cfg.node_id,CURRENT_MAP_ID:cfg.map_id,PENDING_CHOICE_GROUP_ID:'',PENDING_INPUT_JSON:'{}'});
 r.s.quests.Q_ISK_MOND_02={state:'진행중',node:'ACTIVE',claimed:false};
 const owned=copy(r.s.chars[OWNER]),eligibility=r.s.global.COMPANION_ELIGIBILITY_JSON;
 r.startBattle(GROUP,'STORY:'+cfg.node_id,{confirmed:true,companions:[OWNER]});
 const b=r.s.runtime;assert(b?.storyConfig?.node_id===cfg.node_id);
 const guest=b.actors.find(a=>a.side==='ALLY'&&a.source===OWNER);assert(guest?.guest);
 const snapshot=r.s.guestSnapshots[cfg.node_id][OWNER];assert(snapshot&&snapshot!==guest);
 const from=r.row('26_LEVEL_RULES',snapshot.level),to=r.row('26_LEVEL_RULES',level);
 const maximum=Math.round(snapshot.maxHp*Number(to[4])/Number(from[4]));
 for(const state of [snapshot,guest]){state.level=level;state.maxHp=maximum;state.hp=hp;state.xp=level===20?0:r.row('26_LEVEL_RULES',level)[2]-1;}
 return {r,gate:cfg.node_id,owned,eligibility};
}

function settle(env,scenario){
 const f=fixture(env,scenario),r=f.r,b=r.s.runtime;
 const before=copy(r.s.guestSnapshots[f.gate][OWNER]),guest=b.actors.find(a=>a.side==='ALLY'&&a.source===OWNER);
 const settledHp=guest.hp,victory=scenario.victory!==false;
 if(victory)for(const enemy of b.actors.filter(a=>a.side==='ENEMY'))enemy.hp=0;
 const receipt=copy(r.finishBattle(victory));assert.equal(receipt.victory,victory);
 // Read the committed state afresh: settlement may replace runtime/state refs.
 const after=copy(r.s.guestSnapshots[f.gate][OWNER]);let expectedLevel=before.level,total=(before.xp||0)+(victory?receipt.xp:0);
 if(victory)while(expectedLevel<20&&total>=Number(r.row('26_LEVEL_RULES',expectedLevel)[2])){total-=Number(r.row('26_LEVEL_RULES',expectedLevel)[2]);expectedLevel++;}
 const expectedMax=expectedLevel>before.level?Math.round(before.maxHp*Number(r.row('26_LEVEL_RULES',expectedLevel)[4])/Number(r.row('26_LEVEL_RULES',before.level)[4])):before.maxHp;
 const expectedHp=settledHp>0?Math.min(expectedMax,settledHp+Math.max(0,expectedMax-before.maxHp)):0;
 assert.equal(after.level,expectedLevel);assert.equal(after.maxHp,expectedMax);assert.equal(after.hp,expectedHp);
 assert.equal(after.xp,victory?(expectedLevel===20?0:total):before.xp);
 assert.deepEqual(copy(r.s.chars[OWNER]),f.owned,'story guest settlement must not change the permanently owned character record');
 assert.equal(r.s.global.COMPANION_ELIGIBILITY_JSON,f.eligibility,'story guest growth never grants ownership');
 assert.equal(r.premiumOwns(OWNER),false);
 if(scenario.multiLevel)assert(after.level>=before.level+2,'authored native XP must cross multiple guest level thresholds');
 if(scenario.noLevel)assert.equal(after.level,before.level);
 if(settledHp>0)assert.equal(after.maxHp-after.hp,before.maxHp-settledHp,'absolute wound remains after guest growth');
 return {before,settledHp,after,receipt:{victory:receipt.victory,xp:receipt.xp},permanentUnchanged:true,ownershipUnchanged:true};
}

function runNative(env,{onCase=()=>{}}={}){
 assert(env?.R&&env.db,'native Runtime and DB environment are required');
 const scenarios=[
  {name:'living story guest keeps absolute wounds across multiple native XP levels',level:1,hp:1,multiLevel:true},
  {name:'KO story guest gains native XP levels without revival',level:1,hp:0,multiLevel:true},
  {name:'living capped guest gets neither invented growth nor a free heal',level:20,hp:1,noLevel:true},
  {name:'KO capped guest remains KO after a victory',level:20,hp:0,noLevel:true},
  {name:'defeated story guest retains HP and XP without growth',level:1,hp:1,victory:false,noLevel:true},
 ];
 const cases=scenarios.map(scenario=>{const result={name:scenario.name,passed:true,...settle(env,scenario)};onCase(result);return result;});
 return {schema:1,passed:true,counts:{cases:cases.length,passed:cases.length,failed:0},assumptions:['Real authored Isekai AA Dvalin story configuration and native startBattle/finishBattle chain.','Guest start level, XP and end-of-battle wounds/KO are explicit isolated accounting fixtures. Enemies are set defeated before native victory settlement; no combat win-rate claim.','No XP, growth, healing, sanitation or settlement function is replaced. Permanently owned state and JOINED eligibility must stay unchanged.'],cases};
}

if(require.main===module){
 try{
  const sourceRoot=path.resolve(process.env.GUEST_SOURCE_ROOT||path.join(__dirname,'..'));
  const env=require('../tools/audit_food_lodging_v01617.cjs').loadEnvironment(sourceRoot);
  const report=runNative(env,{onCase:r=>console.log('PASS '+r.name)});
  if(process.env.GUEST_EVIDENCE_OUT)fs.writeFileSync(process.env.GUEST_EVIDENCE_OUT,JSON.stringify({provenance:env.provenance,...report},null,2)+'\n');
  console.log(JSON.stringify(report,null,2));
 }catch(error){console.error(error.stack||error);process.exitCode=1;}
}
module.exports={runNative};
